cd latex && xelatex -interaction=nonstopmode -halt-on-error main.tex (twice); requires XeLaTeX/ctex/Fandol/Latin Modern
Portable typesetting source and fixed numeric evidence; raw token streams, dependency binaries and model weights are separate. This manifest does not claim overall task completion.
