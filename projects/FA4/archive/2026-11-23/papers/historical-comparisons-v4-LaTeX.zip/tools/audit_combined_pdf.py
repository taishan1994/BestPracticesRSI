"""Check rendered, model-local E2E rows and all case-local operator ratios."""
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path
import fitz

P = Path(__file__).resolve().parent
V = P.parent
parser = argparse.ArgumentParser()
parser.add_argument('--partial', action='store_true')
args = parser.parse_args()
suffix = '-partial' if args.partial else ''
out = P / ('latex-combined' + suffix)
load = lambda p: json.loads(p.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
compact = lambda s: re.sub(r'\s+', '', s)
audit_path = V / 'reports' / ('e2e-partial-audit.json' if args.partial else 'e2e-audit.json')
summary_path = V / 'reports' / ('e2e-results-partial.json' if args.partial else 'e2e-results.json')
audit, summary = load(audit_path), load(summary_path)
composition = load(out / 'composition-manifest.json')
assert composition['audit_sha256'] == summary['audit_sha256'] == digest(audit_path)
assert composition['summary_sha256'] == digest(summary_path)
for name, expected in composition['files'].items():
    assert digest(out / name) == expected
pdf = fitz.open(out / 'main.pdf')
text = compact('\n'.join(page.get_text() for page in pdf))
project_links = load(out / 'project-links.json')
catalog_path = V / 'reports/project-status-v3.json'
sources_path = V.parents[1] / 'research/fa4-pro6000-final/sources.csv'
assert project_links['catalog_sha256'] == digest(catalog_path)
assert project_links['sources_sha256'] == digest(sources_path)
catalog = load(catalog_path)['projects']
sources = {r['source_id']: r for r in csv.DictReader(sources_path.open(encoding='utf-8-sig'))}
actual_links = {link.get('uri') for page in pdf for link in page.get_links()}
assert len(catalog) == len(project_links['rows']) == 15
for project, link in zip(catalog, project_links['rows']):
    assert link['project'] == project['id']
    assert link['url'] == sources[project['source_ids'][0]]['url']
    assert link['url'] in actual_links, link['url']
    assert compact(project['name']) in text, project['name']
assert '正式模型吞吐未完成' not in text
assert '本文仅完成算子比较和profiler分析' not in text
if args.partial:
    assert '合并排版预览' in text and '阶段数据' in text
else:
    assert audit['suite_status'] == 'completed' and len(audit['servers']) == 10
    assert '阶段数据' not in text and '端到端尚未完成' not in text

heads = list(re.finditer(r'场景(\d+)：', text))
assert len(heads) == 24
chunks = {int(m.group(1)): text[m.start(): heads[i+1].start() if i+1 < 24 else text.index('NCU与MFU：优势及边界', m.start())]
          for i, m in enumerate(heads)}
operator_checks = 0
for row in load(P / 'per-scenario-v3_1-data.json')['rows']:
    chunk = chunks[row['case']]
    assert row['shape'] in chunk
    for key in ['candidate_graph_us', 'candidate_call_us']:
        assert f'{row[key]:.3f}' in chunk
    if row['status'] == 'outside declared recipe scope':
        continue
    for metric in ['graph', 'call']:
        r = row[metric]
        if r['relative_gain_pct'] is None:
            continue
        value = 1 + r['relative_gain_pct'] / 100
        lo, hi = [1 + x / 100 for x in r['ci95_gain_pct']]
        assert f'{value:.3f}[{lo:.3f},{hi:.3f}]' in chunk
        assert f"{r['baseline_ms']*1000:.3f}" in chunk
        operator_checks += 1
assert operator_checks == 444
ncu_path = V / 'reports/ncu-analysis.json'
ncu_table = load(out / 'ncu-table-rows.json')
assert composition['ncu_sha256'] == ncu_table['ncu_sha256'] == digest(ncu_path)
ncu_source = load(ncu_path)['rows']
assert len(ncu_source) == len(ncu_table['rows']) == 23
ncu_text = text[text.index('NCU样例的完整数值对照'):text.index('模型端到端：约束下的吞吐比较')]
ncu_checks = 0
for source, row in zip(ncu_source, ncu_table['rows']):
    assert (source['shape'], source['method'], source['cache']) == (row['shape'], row['method'], row['cache'])
    s = source['evidence']['summary']
    m = source['unprofiled_operator_mfu']
    for key, value in [('l2_pct', s['l2_hit_pct']), ('sm_pct', s['sm_throughput_pct']),
                       ('dram_pct', s['dram_throughput_pct']), ('warm_mfu_pct', m['operator_mfu']*100),
                       ('warm_graph_us', m['unprofiled_latency_ms']*1000)]:
        assert row[key] == value
    expected = str(row['case']) + compact(row['label']) + ('热' if row['cache']=='warm' else '冷')
    expected += ''.join('N/A' if row[key] is None else f'{row[key]:.2f}'
                        for key in ['l2_pct', 'sm_pct', 'dram_pct', 'warm_mfu_pct'])
    expected += f"{row['warm_graph_us']:.3f}"
    assert expected in ncu_text, expected
    ncu_checks += 1

labels = {'fa4_rsi': '本配方FA4', 'fa4_reference_rsi': '官方FA4适配参考',
          'torch_flash_rsi': 'PyTorch原生Flash（KV适配）',
          'flashinfer': 'FlashInfer原生后端', 'triton': 'Triton原生后端'}
models = sorted({r['model'] for r in summary['rows']})
# Bound checks to actual model subsections, rather than matching numbers elsewhere.
e2e = text[text.index('模型端到端：约束下的吞吐比较'):]
positions = sorted((e2e.index(model), model) for model in models)
model_text = {model: e2e[start:positions[i+1][0] if i+1 < len(positions)
                       else e2e.index('生成token复现记录', start)]
              for i, (start, model) in enumerate(positions)}
summary_checks = search_checks = 0
for row in summary['rows']:
    chunk = model_text[row['model']]
    workload_start = chunk.index('Prefill：' if row['workload'] == 'prefill' else 'Decode：')
    stop = chunk.index('Decode：', workload_start) if row['workload'] == 'prefill' and 'Decode：' in chunk[workload_start:] else chunk.index('完整搜索点')
    chunk = chunk[workload_start:stop]
    c = str(row['best_confirmed_concurrency']) if row['confirmed_eligible'] else '无达标点'
    latency = f"{row['confirmation_latency_ms']:.3f}" if row['confirmation_latency_ms'] is not None else '–'
    ratio = next((p['throughput_speedup'] for p in summary['ratios']
                  if p['model'] == row['model'] and p['workload'] == row['workload']
                  and p['baseline'] == row['backend']), None)
    rs = '1.000' if row['backend'] == 'fa4_rsi' and row['confirmed_eligible'] else '–' if ratio is None else f'{ratio:.3f}'
    expected = labels[row['backend']] + c + latency + f"{row['admitted_throughput']:.3f}" + rs
    assert expected in chunk, (row['model'], row['workload'], expected)
    summary_checks += 1
for point in audit['points']:
    if '-confirm' in point['point']:
        continue
    prefill = point['workload'] == 'prefill'
    e = point['evaluation']
    expected = (('Prefill/TTFT' if prefill else 'Decode/TPOT') + labels[point['backend']]
                + str(point['concurrency']) + str(e['requests'])
                + f"{e['mean_ttft_ms' if prefill else 'mean_tpot_ms']:.3f}"
                + f"{e['input_throughput' if prefill else 'output_throughput']:.3f}"
                + ('是' if e['eligible'] else '否'))
    assert expected in model_text[point['model']], expected
    search_checks += 1
assert 'Overfull' not in (out / 'main.log').read_text()
quality = text[text.index('生成token复现记录'):text.index('服务数值门禁与长度勘误')]
quality_checks = 0
for agreement in audit.get('formal_token_agreement', []):
    exact = sum(row['exact_match'] for row in agreement['pairs'])
    expected = (agreement['model'] + labels[agreement['baseline']]
                + str(agreement['output_tokens_per_request']) + str(exact) + '/10')
    assert expected in quality, expected
    quality_checks += 1
result = dict(status='partial-layout-audited' if args.partial else 'rendered-numeric-audited',
              pages=len(pdf), operator_ratio_ci_checks=operator_checks,
              ncu_numeric_rows=ncu_checks, ncu_sha256=digest(ncu_path),
              project_source_links=len(project_links['rows']),
              model_local_summary_rows=summary_checks, model_local_search_rows=search_checks,
              token_agreement_rows=quality_checks,
              pdf_sha256=digest(out / 'main.pdf'), audit_sha256=digest(audit_path),
              scope='Rendered numeric coverage only; no final archive or cleanup claim.')
(out / 'pdf-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
