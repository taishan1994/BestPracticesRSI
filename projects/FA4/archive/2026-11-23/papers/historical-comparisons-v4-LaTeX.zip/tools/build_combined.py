"""Compose frozen operator evidence and audited E2E without stale stage prose.

--partial is a layout preview only. Full output requires the completed suite,
the full raw audit and matching table/figure exports; no final manifest is
created here because rendering, numeric audit and archive checks come later.
"""
import argparse
import csv
import hashlib
import json
import re
import shutil
from pathlib import Path

P = Path(__file__).resolve().parent
V = P.parent
parser = argparse.ArgumentParser()
parser.add_argument('--partial', action='store_true')
args = parser.parse_args()
suffix = '-partial' if args.partial else ''
load = lambda p: json.loads(p.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
audit_path = V / 'reports' / ('e2e-partial-audit.json' if args.partial else 'e2e-audit.json')
summary_path = V / 'reports' / ('e2e-results-partial.json' if args.partial else 'e2e-results.json')
audit, summary = load(audit_path), load(summary_path)
assert summary['audit_sha256'] == digest(audit_path)
if not args.partial:
    assert audit['status'] == summary['status'] == 'audited'
    assert audit['suite_status'] == 'completed' and len(audit['servers']) == 10
    assert not audit['pending']
tables = P / ('e2e-tex' + suffix)
figures = P / ('e2e-figures' + suffix)
tm, fm = load(tables / 'manifest.json'), load(figures / 'manifest.json')
for manifest in [tm, fm]:
    assert manifest['audit_sha256'] == digest(audit_path)
    assert manifest['summary_sha256'] == digest(summary_path)
assert tm['latex_sha256'] == digest(tables / 'results.tex')
for name, expected in fm['outputs'].items():
    assert digest(P / name) == expected
gate = load(V / 'reports/serving-validation-extended-002.json')
assert gate['pass_'] and len(gate['rows']) == 33
assert next(value for name, value in gate['sources'].items()
            if name.endswith('/fa4_service_backend.py')) == digest(V / 'e2e/fa4_service_backend.py')

out = P / ('latex-combined' + suffix)
out.mkdir(exist_ok=True)
source = P / 'latex-v3_1'
body = (source / 'body.tex').read_text()
# Keep all 24 primary case tables and the complete NCU discussion verbatim.
boundary = body.index(r'\section{端到端协议与当前状态}')
body = body[:boundary]
ncupath = V / 'reports/ncu-analysis.json'
ncu = load(ncupath)
assert ncu['status'] == 'audited' and len(ncu['rows']) == 23
case_ids = {r['shape']: r['case'] for r in load(P / 'per-scenario-v3_1-data.json')['rows']}
ncu_labels = {'official': '官方FA4', 'ours': '通用本配方', 'sdpa-cudnn': 'SDPA cuDNN',
              'flashinfer': 'FlashInfer FA2', 'fa2': 'FA2',
              'thad-default': 'PR2634默认', 'ours-decode': '专用decode配方'}
body += r'''
\clearpage\onecolumn\section{NCU 样例的完整数值对照}
下表列出全部 23 份采集，场景号对应前文完整形状。
L2 为有效命中比例，SM 与 DRAM 为 NCU sustained peak 百分比；三者均不是 occupancy。
MFU 与图内时间来自独立、无 profiler 的热图内测量；冷缓存采集行也仅引用该独立热计时，
不代表冷缓存延迟或冷缓存 MFU。热采集采用 application replay、不清 cache；
冷采集采用 kernel replay、清 cache。全部调用中的内核均计入。
通用本配方与唯一单 token 专用 decode 配方分列；实际冻结候选以逐场景主表为准。
\begin{center}\footnotesize\begin{longtable}{rllrrrrr}
\toprule 场景 & 配方 & 重放缓存 & L2 \% & SM \% & DRAM \% & 热图内 MFU \% & 热图内 $\mu$s\\\midrule\endhead
'''
ncu_rows = []
fmt = lambda value, digits=2: 'N/A' if value is None else f'{value:.{digits}f}'
for row in ncu['rows']:
    summary = row['evidence']['summary']
    mfu = row['unprofiled_operator_mfu']
    entry = dict(case=case_ids[row['shape']], shape=row['shape'], method=row['method'],
                 label=ncu_labels[row['method']], cache=row['cache'],
                 l2_pct=summary['l2_hit_pct'], sm_pct=summary['sm_throughput_pct'],
                 dram_pct=summary['dram_throughput_pct'],
                 warm_mfu_pct=100*mfu['operator_mfu'],
                 warm_graph_us=1000*mfu['unprofiled_latency_ms'])
    ncu_rows.append(entry)
    cells = [str(entry['case']), entry['label'], '热' if entry['cache']=='warm' else '冷']
    cells += [fmt(entry[k]) for k in ['l2_pct', 'sm_pct', 'dram_pct', 'warm_mfu_pct']]
    cells += [fmt(entry['warm_graph_us'], 3)]
    body += ' & '.join(cells) + r'\\' + '\n'
body += r'''
\bottomrule\end{longtable}\end{center}
N/A 表示多遍重放的原始 L2 比率超出有效概率范围，原始值仍保留，未截断或补零。
SM120 工具缺少 DRAM 读写字节计数器，因此本文仅报告可用的 DRAM throughput 百分比，
不将它换算成未经测量的 GB/s。低 DRAM 百分比、高 L2 与较低 MFU 不能单独证明某一种瓶颈。
'''
(out / 'ncu-table-rows.json').write_text(json.dumps(dict(ncu_sha256=digest(ncupath), rows=ncu_rows), indent=2)+'\n')
body += r'''
\subsection{跨 GPU 对比的证据边界}
本研究所有本地性能结果均来自物理 GPU0 的 RTX PRO 6000 Server Edition。
项目资料中的 B200、GB200、RTX 5090 或 Max-Q 工作站结果保留各自来源范围，
没有在其他 GPU 上执行同一套冻结协议，因此不构造本机对其他 GPU 的实测加速比。
同名 FA4 的版本、架构路径、形状、精度和计时边界可能不同；公开平台数字
不能直接除以本文算子耗时，也不能将芯片峰值比例作为真实注意力性能比例。
\clearpage\onecolumn
\input{e2e-results.tex}
\subsection{搜索范围与运行时边界}
预注册并发序列为 1、2、4、8、16；至少完成三个点，在连续两点不达标后停止。
存在合格点时，在最高合格幂次与其后的首个不合格幂次之间逐整数细化；
两次独立确认仅用于搜索范围内最优点，不宣称全局最优或延迟随并发单调。
模型运行时使用 Torch2.13/CUDA13.0 与独立服务 overlay；算子比较使用
Torch2.11/CUDA13.2，二者分开报告，不跨运行时相除生成加速比。
服务版本名含 dflash2，实际加载的 SpeculativeAlgorithm 与 server-info
读回均要求 NONE，模型 runner 另行证明未启用投机。
客户端普通最终 token 采样后端名不作为投机解码启用证据。
\subsection{服务数值门禁与长度勘误}
服务扩展有独立运行时和源码绑定，不将旧的单 token 专用配方外推到两个模型。
扩展验证覆盖三种共同 KV 适配模式的 33 个独立场景，包含 Qwen D256、Muse
非默认 scale、滑窗、8192 prefill、混合 9216/8193/4097 长度 decode、
多流、独立输出，以及同图改变输入、长度和跨 tile 增长 129 token。
参考计算禁用 TF32 并有 FP64 短控制。修正后的 002 门禁全部通过。

首次扩展验证有三项失败：缩短长度使滑窗重新暴露已经回收的 KV，旧参考将
负页号错误解释为真实末页。原始失败及源码保留；修正参考先拒绝缺失的可见
KV，对已回收历史采用合法的向前回放，并加入三项拒绝无效回退的负控制。
未放宽容差或修改生产服务内核。Muse 实际 scale 为 $3.87/\sqrt{128}$。

初次端到端配置的 9216 上下文被框架预留位置，导致 1024 输出截为 1022；
长度门禁拒绝该次尝试。正式修正版统一上下文 10240，输入输出要求、精度与
SLA 不变。旧配置五个 prefill 观察仅保留为历史，不混入当前对照。
\subsection{吞吐与延迟曲线}
曲线连接完整搜索请求组，独立确认点另列；红色阴影表示相应平均延迟超过门槛。
两次确认的范围不是置信区间，未达标吞吐不用于合格吞吐加速比。
'''
validation_start = body.index(r'\subsection{服务数值门禁与长度勘误}')
curves_start = body.index(r'\subsection{吞吐与延迟曲线}')
validation = body[validation_start:curves_start]
body = body[:validation_start] + body[curves_start:]
for model in fm['models']:
    target = figures / (model + '.pdf')
    assert target.exists()
    shutil.copyfile(target, out / ('e2e-' + model + '.pdf'))
    body += ('\n\\begin{center}\\includegraphics[width=\\textwidth]{e2e-'
             + model + '.pdf}\\end{center}\n')
body += validation
body += r'''
\clearpage\twocolumn\section{RSI 进化与复核}
可选 profiler reader 保留超界 L2、缺失 counter 与严格参考精度边界；
原始 108 个进程、23 份 NCU 报告与全部样本通过来源哈希绑定。
算子计数器版本完成 67 项回归，其中包含九项新模块检查。
逐场景报告缺项另形成可选 reporting 版本：总计 72 项回归通过，
其中五项新增检查会拒绝只有胜场统计、缺少场景或颠倒慢点的报告。
其真实数据回放包含 528 个计时比较栏，其中 444 个有效加速比及区间；
其余失败或范围外比较保持 N/A。两个版本均有独立源码归档与解压回放，
不改变旧 SLA、冻结测量协议或原始证据。

逐场景速度比与区间来自五轮配对算子记录；模型吞吐来自完整请求组墙钟，
不得混用。服务 33 项 GPU 门禁、生成 token 复现记录与任务准确率是不同证据，
后者未由本文测量。来源范围仍按附录逐项目说明。
'''
main = (source / 'main.tex').read_text().replace(
    r'逐场景加速比报告 v3.1；含绝对时间与 95\% 区间',
    '合并排版预览；端到端尚未完成' if args.partial else '算子、NCU 与模型端到端完整对照')
assert '端到端协议与当前状态' not in body
assert '正式模型吞吐未完成' not in body
shutil.copyfile(source / 'references.tex', out / 'references.tex')
# Keep each project's source immediately beside its fixed-version scope,
# rather than requiring the reader to locate an older PDF's bibliography.
catalog_path = V / 'reports/project-status-v3.json'
sources_path = V.parents[1] / 'research/fa4-pro6000-final/sources.csv'
catalog = load(catalog_path)['projects']
sources = {r['source_id']: r for r in csv.DictReader(sources_path.open(encoding='utf-8-sig'))}
projects = (source / 'projects.tex').read_text()
headings = list(re.finditer(r'\\subsection\{[^}]+\}', projects))
assert len(headings) == len(catalog) == 15
linked_projects = []
for heading, project in reversed(list(zip(headings, catalog))):
    title = heading.group()[len(r'\subsection{'):-1]
    assert ''.join(title.split()) == ''.join(project['name'].split())
    url = sources[project['source_ids'][0]]['url']
    linked_projects.append(dict(project=project['id'], url=url))
    projects = projects[:heading.end()] + '\n' + r'\noindent\textbf{来源：}\url{' + url + '}\n' + projects[heading.end():]
projects = projects.replace('研究覆盖十五个项目，不代表执行了十五种互相独立的 FA4 算法。',
    '研究覆盖十五个项目，不代表执行了十五种互相独立的 FA4 算法。来源链接对应已调研资料；结论限定为归档版本，可变主分支链接不代表未来状态。')
(out / 'projects.tex').write_text(projects)
(out / 'project-links.json').write_text(json.dumps(dict(catalog_sha256=digest(catalog_path), sources_sha256=digest(sources_path), rows=list(reversed(linked_projects))), indent=2)+'\n')
shutil.copytree(source / 'figures', out / 'figures', dirs_exist_ok=True)
shutil.copyfile(tables / 'results.tex', out / 'e2e-results.tex')
(out / 'body.tex').write_text(body)
(out / 'main.tex').write_text(main)
manifest = dict(status='partial-layout-preview' if args.partial else 'unrendered-full-source',
                audit_sha256=digest(audit_path), summary_sha256=digest(summary_path),
                ncu_sha256=digest(ncupath),
                operator_body_sha256=digest(source / 'body.tex'),
                files={name: digest(out / name) for name in
                       ['main.tex', 'body.tex', 'projects.tex', 'references.tex', 'e2e-results.tex', 'ncu-table-rows.json', 'project-links.json']},
                scope='Composition only; rendering, numeric PDF audit, archives and cleanup still required.')
(out / 'composition-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
