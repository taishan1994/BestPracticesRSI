"""Publish local final PDF and portable LaTeX sources after the full audit.

Does not declare overall completion: raw archive and cleanup checks follow.
Never overwrites previously emitted deliverables.
"""
import hashlib
import json
import zipfile
from pathlib import Path

P = Path(__file__).resolve().parent
V = P.parent
L = P / 'latex-combined'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
audit_path = V / 'reports/e2e-audit.json'
summary_path = V / 'reports/e2e-results.json'
audit, summary = load(audit_path), load(summary_path)
rendered = load(L / 'pdf-audit.json')
assert audit['status'] == summary['status'] == 'audited'
assert audit['suite_status'] == 'completed' and len(audit['servers']) == 10 and not audit['pending']
assert summary['audit_sha256'] == rendered['audit_sha256'] == sha(audit_path)
inputs = load(V / 'reports/final-input-audit.json')
assert inputs['status'] == 'verified' and inputs['audit_sha256'] == sha(audit_path)
assert len(inputs['source_bindings']) == 10 and len(inputs['weight_files']) == 20
assert all(row['matches_initial'] for row in inputs['weight_files'])
assert rendered['status'] == 'rendered-numeric-audited'
assert rendered['operator_ratio_ci_checks'] == 444
assert rendered['ncu_numeric_rows'] == 23
assert rendered['project_source_links'] == 15
assert rendered['ncu_sha256'] == sha(V / 'reports/ncu-analysis.json')
assert rendered['model_local_summary_rows'] == len(summary['rows'])
assert rendered['model_local_search_rows'] == sum('-confirm' not in p['point'] for p in audit['points'])
assert rendered['token_agreement_rows'] == len(audit['formal_token_agreement'])
assert sha(L / 'main.pdf') == rendered['pdf_sha256']
composition = load(L / 'composition-manifest.json')
assert composition['status'] == 'unrendered-full-source'
assert composition['audit_sha256'] == sha(audit_path)
assert composition['summary_sha256'] == sha(summary_path)
for name, expected in composition['files'].items():
    assert sha(L / name) == expected

pdf = P / 'FA4-SM120-Comparisons-Final-v4.pdf'
source_zip = P / 'FA4-SM120-Comparisons-Final-v4-LaTeX.zip'
assert not pdf.exists() and not source_zip.exists()
members = {}
for path in sorted(L.rglob('*')):
    if path.is_file() and path.suffix in ['.tex', '.pdf', '.json'] and path.name != 'main.pdf':
        members['latex/' + str(path.relative_to(L))] = path
for name in ['details-template-provenance.json', 'per-scenario-v3_1-data.json',
             'per-scenario-speedups-v3_1.csv', 'per-scenario-v3_1-audit.json']:
    members['evidence/' + name] = P / name
for path in [audit_path, summary_path, V / 'reports/final-input-audit.json']:
    members['evidence/' + path.name] = path
for name in ['build_combined.py', 'audit_combined_pdf.py', 'package_final_paper.py',
             'plot_e2e.py', 'render_e2e_tables.py']:
    members['tools/' + name] = P / name
manifest = dict(status='rendered-paper-and-source-only', pdf_sha256=sha(L / 'main.pdf'),
                pages=rendered['pages'], audit_sha256=sha(audit_path),
                members={name: sha(path) for name, path in members.items()},
                compile='cd latex && xelatex -interaction=nonstopmode -halt-on-error main.tex (twice); requires XeLaTeX/ctex/Fandol/Latin Modern',
                scope='Portable typesetting source and fixed numeric evidence; raw token streams, dependency binaries and model weights are separate. This manifest does not claim overall task completion.')
with zipfile.ZipFile(source_zip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(members.items()):
        z.write(path, name)
    z.writestr('SOURCE-MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
    z.writestr('README.txt', manifest['compile'] + '\n' + manifest['scope'] + '\n')
with zipfile.ZipFile(source_zip) as z:
    assert z.testzip() is None
    for name, expected in manifest['members'].items():
        assert hashlib.sha256(z.read(name)).hexdigest() == expected
with pdf.open('xb') as f:
    f.write((L / 'main.pdf').read_bytes())
assert sha(pdf) == rendered['pdf_sha256']
receipt = dict(status='verified-paper-artifacts-only', pages=rendered['pages'],
               artifacts={path.name: sha(path) for path in [pdf, source_zip]},
               latex_crc_verified=True, verified_source_members=len(members),
               audit_sha256=sha(audit_path))
(P / 'final-paper-artifacts.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
