"""Scientific SLO/throughput curves from audited completed cohorts only."""
import argparse,hashlib,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
V=Path(__file__).resolve().parents[1];P=V/'paper'
ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');a=ap.parse_args()
suffix='-partial' if a.partial else ''
auditpath=V/'reports'/('e2e-partial-audit.json' if a.partial else 'e2e-audit.json')
resultpath=V/'reports'/('e2e-results-partial.json' if a.partial else 'e2e-results.json')
audit=json.loads(auditpath.read_text());summary=json.loads(resultpath.read_text())
assert summary['audit_sha256']==hashlib.sha256(auditpath.read_bytes()).hexdigest(),'summary must bind this exact raw-stream audit'
if not a.partial:assert audit['status']=='audited' and summary['status']=='audited' and len(audit['servers'])==10
labels={'fa4_rsi':'Our FA4','fa4_reference_rsi':'Official FA4 adapted','torch_flash_rsi':'PyTorch native Flash','flashinfer':'Native FlashInfer','triton':'Native Triton'}
colors={'fa4_rsi':'#147d92','fa4_reference_rsi':'#e27d30','torch_flash_rsi':'#6658a5','flashinfer':'#518a36','triton':'#bb4d69'}
markers={'fa4_rsi':'o','fa4_reference_rsi':'s','torch_flash_rsi':'^','flashinfer':'D','triton':'v'}
models=sorted({p['model'] for p in audit['points']});out=P/('e2e-figures-partial' if a.partial else 'e2e-figures');out.mkdir(exist_ok=True)
outputs=[]
for model in models:
 fig,axes=plt.subplots(1,2,figsize=(9.5,3.7))
 for ax,workload in zip(axes,['prefill','decode']):
  field='mean_ttft_ms' if workload=='prefill' else 'mean_tpot_ms';objective='input_throughput' if workload=='prefill' else 'output_throughput';bound=2000 if workload=='prefill' else 30;scale=.001 if workload=='prefill' else 1
  groups={}
  for p in audit['points']:
   if p['model']!=model or p['workload']!=workload or '-confirm' in p['point']:continue
   groups.setdefault(p['backend'],[]).append(p)
  maxx=bound*scale*1.1;maxy=1
  for j,(backend,points) in enumerate(groups.items()):
   points.sort(key=lambda p:p['concurrency']);xx=[p['evaluation'][field]*scale for p in points];yy=[p['evaluation'][objective] for p in points]
   maxx=max(maxx,max(xx)*1.12)
   maxy=max(maxy,max(yy))
   ax.plot(xx,yy,color=colors[backend],lw=1.1,ls='-' if backend=='fa4_rsi' else '--',label=labels[backend])
   for p,x,y in zip(points,xx,yy):
    eligible=p['evaluation']['eligible'];ax.scatter(x,y,marker=markers[backend],s=32,edgecolor=colors[backend],facecolor=colors[backend] if eligible else 'white',zorder=4)
    ax.annotate('C'+str(p['concurrency']),(x,y),xytext=(4,5 if j%2==0 else -11),textcoords='offset points',fontsize=6,color=colors[backend])
  for row in summary['rows']:
   if row['model']!=model or row['workload']!=workload or not row['confirmed_eligible']:continue
   backend=row['backend'];repeats=row['confirmation'];x=row['confirmation_latency_ms']*scale;y=row['admitted_throughput']
   xs=[r['evaluation'][field]*scale for r in repeats];lo,hi=row['repeat_throughput_range']
   maxy=max(maxy,hi)
   ax.errorbar(x,y,xerr=[[max(0,x-min(xs))],[max(0,max(xs)-x)]],yerr=[[max(0,y-lo)],[max(0,hi-y)]],fmt='P',markersize=7,color=colors[backend],ecolor=colors[backend],capsize=2,zorder=5)
  ax.axvline(bound*scale,color='#aa3333',lw=1.1);ax.set_xlim(0,maxx);ax.axvspan(bound*scale,maxx,color='#bb3333',alpha=.055)
  ax.set_ylim(0,maxy*1.18);ax.grid(alpha=.17);ax.set_axisbelow(True);ax.set_title('Prefill: 8192 / 1' if workload=='prefill' else 'Decode: 8192 / 1024',fontsize=10)
  ax.set_xlabel('Mean TTFT (s)' if workload=='prefill' else 'Mean TPOT (ms)');ax.set_ylabel('Observed input token/s' if workload=='prefill' else 'Observed output token/s')
  ax.text(.98,.03,'Hollow: SLA miss; +: pooled confirmations',transform=ax.transAxes,ha='right',fontsize=6,color='#555555')
 handles,names=axes[0].get_legend_handles_labels();h2,n2=axes[1].get_legend_handles_labels()
 for handle,name in zip(h2,n2):
  if name not in names:handles.append(handle);names.append(name)
 fig.legend(handles,names,loc='lower center',ncol=min(len(names),3),fontsize=7,frameon=False)
 fig.suptitle(model+(' — PARTIAL: completed cohorts only' if a.partial else ' — ordinary autoregressive, no speculation'),fontsize=10)
 fig.tight_layout(rect=[0,.10,1,.94])
 for ext in ['pdf','png','svg']:
  path=out/(model+'.'+ext);fig.savefig(path,dpi=220,bbox_inches='tight');outputs.append(path)
 plt.close(fig)
manifest=dict(status='partial' if a.partial else 'verified-data-export',audit_sha256=hashlib.sha256(auditpath.read_bytes()).hexdigest(),summary_sha256=hashlib.sha256(resultpath.read_bytes()).hexdigest(),models=models,outputs={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs},scope='Observed throughput at each complete search/refinement cohort, with mean-latency gate shaded. Misses are not admitted throughput. Pooled independent confirmations shown separately; interval bars show repeat ranges, not confidence intervals. Pending points and models are omitted, never filled with synthetic values.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
