"""Evidence-bound LaTeX fragment for the final E2E section; partial is explicit."""
import argparse,hashlib,json
from pathlib import Path
V=Path(__file__).resolve().parents[1];P=V/'paper'
ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');a=ap.parse_args()
resultpath=V/'reports'/('e2e-results-partial.json' if a.partial else 'e2e-results.json');auditpath=V/'reports'/('e2e-partial-audit.json' if a.partial else 'e2e-audit.json')
load=lambda p:json.loads(p.read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=load(resultpath);audit=load(auditpath);assert s['audit_sha256']==h(auditpath)
if not a.partial:assert s['status']=='audited' and audit['status']=='audited' and audit['suite_status']=='completed' and len(audit['servers'])==10
out=P/('e2e-tex-partial' if a.partial else 'e2e-tex');out.mkdir(exist_ok=True)
labels={'fa4_rsi':'本配方 FA4','fa4_reference_rsi':'官方 FA4 适配参考','torch_flash_rsi':'PyTorch 原生 Flash（KV适配）','flashinfer':'FlashInfer 原生后端','triton':'Triton 原生后端'}
esc=lambda x:str(x).replace('_',r'\_').replace('%',r'\%').replace('&',r'\&')
lines=[r'\section{模型端到端：约束下的吞吐比较}',r'\textbf{'+('阶段数据：仅列完整结束的请求组和已完成确认的工作负载；完整两模型五后端排名尚未完成。' if a.partial else '完整请求组数据；失败方案另列，不以失败构造无限加速比。')+'}',r'物理 GPU0，输入均为 8192 个固定 token ID，普通自回归生成，所有投机解码关闭。模型权重只读挂载并固定 SHA256；所有后端在同一模型下使用相同 BF16 权重、QKV 与 KV，以及相同非注意力控制。Qwen GDN 使用 Triton 与 FP32 状态缓存。8192/1 仅按 mean TTFT 不超过 2 秒准入，目标为输入 token/s；8192/1024 仅按 mean TPOT 不超过 30 毫秒准入，目标为输出 token/s。每点恰为 10 倍并发的完整请求组，预热不计入。',r'候选最优点由冻结的搜索规则产生，再完整独立重复两次；只有两次都达标才报告确认后的合格吞吐。两次吞吐按 token 总数除以两组完整墙钟跨度之和合并，延迟按有效请求数加权；不挑选较快一次，不把搜索峰值当确认结果。相对吞吐为本配方合格吞吐除以对照合格吞吐，只有双方都有确认达标点才计算。没有准入点时显示 0，不计算 0/0。两次确认仅作描述性比较，不据此作显著性或置信区间声明。',r'官方参考使用 b38 公共 FA4 API 与相同分页 KV 适配；Qwen 的 D256 采用显式 64x64 安全 tile，不能称原封不动的官方默认配置。PyTorch 对照显式调用原生 ATen Flash；与本配方/官方参考共用 KV gather，成本计入端到端。FlashInfer/Triton 使用各自原生服务后端。']
models=sorted({r['model'] for r in s['rows']})
for model in models:
 lines.append(r'\subsection{'+esc(model)+'}')
 for workload,title,latency,throughput in [('prefill','Prefill：8192 输入、1 输出','TTFT','输入'),('decode','Decode：8192 输入、1024 输出','TPOT','输出')]:
  rows=[r for r in s['rows'] if r['model']==model and r['workload']==workload]
  if not rows:continue
  lines+=[r'\paragraph{'+title+'}',r'\begin{center}\small\begin{tabular}{lrrrr}\toprule 方案 & 确认并发 & mean '+latency+r' ms & 合格'+throughput+r' token/s & 本配方/对照\\\midrule']
  for r in rows:
   c=str(r['best_confirmed_concurrency']) if r['confirmed_eligible'] else '无达标点';lat=f"{r['confirmation_latency_ms']:.3f}" if r['confirmation_latency_ms'] is not None else '--'
   ratio=next((p['throughput_speedup'] for p in s['ratios'] if p['model']==model and p['workload']==workload and p['baseline']==r['backend']),None)
   rs='1.000' if r['backend']=='fa4_rsi' and r['confirmed_eligible'] else '--' if ratio is None else f'{ratio:.3f}'
   lines.append(labels[r['backend']]+' & '+c+' & '+lat+' & '+f"{r['admitted_throughput']:.3f}"+' & '+rs+r'\\')
  lines.append(r'\bottomrule\end{tabular}\end{center}')
 lines.append(r'\paragraph{完整搜索点（非确认峰值）}')
 lines += [r'\begin{center}\footnotesize\linespread{1.0}\selectfont\begin{longtable}{llrrrrl}\toprule 工作负载 & 方案 & C & 请求数 & 相应延迟 ms & 实测 token/s & 达标\\\midrule\endhead']
 for p in audit['points']:
  if p['model']!=model or '-confirm' in p['point']:continue
  w=p['workload'];e=p['evaluation'];metric='mean_ttft_ms' if w=='prefill' else 'mean_tpot_ms';objective='input_throughput' if w=='prefill' else 'output_throughput'
  lines.append(('Prefill/TTFT' if w=='prefill' else 'Decode/TPOT')+' & '+labels[p['backend']]+' & '+str(p['concurrency'])+' & '+str(e['requests'])+' & '+f"{e[metric]:.3f}"+' & '+f"{e[objective]:.3f}"+' & '+('是' if e['eligible'] else '否')+r'\\')
 lines += [r'\bottomrule\end{longtable}\end{center}',r'实测吞吐不等于合格吞吐。未达标点保留实测值以解释搜索，不参与最终合格吞吐比。']
agreements=audit.get('formal_token_agreement',[])
if agreements:
 lines += [r'\subsection{生成 token 复现记录}',r'下表比较完全相同的正式并发 1 输入。逐 token 一致率是生成复现诊断，不是任务准确率；发生自回归分岔后，后续上下文也会变化。数值误差门禁与这项诊断分别保留，不自动将分岔归因于舍入，也不宣称所有后端逐 token 等价。',r'\begin{center}\small\begin{tabular}{lllr}\toprule 模型 & 对照 & 输出长度 & 完全一致请求/10\\\midrule']
 for q in agreements:
  lines.append(esc(q['model'])+' & '+labels[q['baseline']]+' & '+str(q['output_tokens_per_request'])+' & '+str(sum(r['exact_match'] for r in q['pairs']))+r'/10\\')
 lines.append(r'\bottomrule\end{tabular}\end{center}')
failed=[r for r in audit['servers'] if r['status'] not in ['completed','running']]
if failed:lines+=[r'\subsection{保留的失败记录}']+[esc(r['model']+' / '+r['backend']+'：'+r['status'])+r'\par' for r in failed]
(out/'results.tex').write_text('\n'.join(lines)+'\n')
manifest=dict(status='partial' if a.partial else 'evidence-export',models=models,summary_sha256=h(resultpath),audit_sha256=h(auditpath),latex_sha256=h(out/'results.tex'),scope='Final-paper component, not a completed two-model report unless full audit/suite is complete. All observed/qualified throughput and token agreement values come from raw-audited cohorts.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
