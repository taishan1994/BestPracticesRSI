# FA4 on RTX PRO 6000 Server Edition (SM120)

This project delivers FA4 inference operator recipes. FA2, cuDNN, FlashInfer and quantized attention projects are research controls or context, never substituted into the FA4 product.

- Research edition already delivered: `paper/FA4-SM120-Research-v1.pdf`; preserve its explicit reference-precision erratum in `reports/reference-precision-erratum.json`.
- Final paper: `paper/FA4-SM120-Final-v2.pdf`; matching LaTeX and evidence: `paper/FA4-SM120-Final-v2-LaTeX.zip`.
- Offline FA4 product bundle: `releases/fa4-sm120-1.0.0-offline.tar.gz`; fresh-container qualification: `reports/rebuild.json`.
- Final paired-round results: `reports/final-results.json`; raw records, failed attempts and independent receipts remain under `runs/`.
- Deployment and rollback: `DEPLOYMENT.md`. Frozen tested source/configuration are in `releases/fa4-sm120-1.0.0/`; graph/eager recommendation mapping is separate in `configs/deployment-recommendations.json`.
- Research catalog: `research/projects.json`, with all 15 projects, version pins, primary-source claims and local dispositions.
- RSI evolution: `configs/rsi-versions.json` selects the optional `core/evolution/releases/operator-rsi-0.1.0/` contracts. Existing model SLA policies are unchanged.

The prefill release keeps upstream FA4 SM120 kernels and qualifies its direct-launch calling contract. The decode release uses a pinned FA4 PR2634 GEMV+combine branch with an explicit return-ABI patch. These are separate source/process profiles. Fixed BF16 decode scope is B1/Q1/K8192/Hq16/Hkv4/D128; no general decode, paged service, training-speed or model-throughput claim is made.

Five independent holdout rounds confirm graph gains in 18/24 cases and Python-inclusive gains in 19/24 cases relative to native FA4 under the predeclared lower-95%-bound >3% rule. The same-fork decode comparison gives approximately 8.40x graph and 5.72x call speed. A failed D256 native default is Not Comparable, not an infinite speedup. Every selected candidate passes the declared strict numerical gate; all metrics are conditional on the fixed device/software/protocol.

All GPU reproduction and dependency installation occurs in containers on physical GPU0. No host Python/CUDA package installation is required.
