"""Final requirement-to-artifact closure, independent of performance search."""
import hashlib,json,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[1];REPO=R.parents[1]
load=lambda p:json.loads(p.read_text())
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks={}
catalog=load(R/'research/projects.json');checks['all_investigated_projects_described']=len(catalog['projects'])==15 and load(R/'reports/final-survey-coverage.json')['pass_']
for name,count in [('compatibility-strict',18),('release-validation',38),('decode-validation',13)]:
    d=load(R/'runs'/f'{name}.json');checks[name]=d['pass_'] and len(d['rows'])==count
final=load(R/'reports/final-results.json')
checks['frozen_source_and_raw_sample_independent_audit']=(R/'reports/final-audit.log').read_text().startswith('graph_ms stock wins 18')
checks['FA4_only_candidate']=final['candidate_family']=='FA4 only'
checks['independent_confirmation']=final['prefill_preflight']['pass_'] and final['wall_preflight']['pass_'] and len(final['cases'])==24
checks['qualified_decode_path']=final['decode']['profile_proven'] and final['decode']['graph_ms']['fa4-default']['promote'] and final['decode']['wall_ms']['fa4-default']['promote']
rebuild=load(R/'reports/rebuild.json')
checks['fresh_GPU0_container']=rebuild['pass_'] and rebuild['cache_initial']['cache_initial_entries']==0 and rebuild['physical_gpu_uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
checks['rebuild_artifacts_unchanged']=all(h(R/p)==s for p,s in rebuild['evidence'].items())
for name,count in [('rebuild-prefill',38),('rebuild-decode',13)]:
    d=load(R/'runs/clean-rebuild'/f'{name}.json');checks[name]=d['pass_'] and len(d['rows'])==count
release=load(R/'releases/release-manifest.json');source=load(R/'releases/fa4-sm120-1.0.0/SOURCE-MANIFEST.json')
checks['offline_release_integrity']=all(h(R/'releases/fa4-sm120-1.0.0'/p)==s for p,s in source['files'].items()) and h(R/release['offline_archive']['path'])==release['offline_archive']['sha256']
checks['validated_image_is_delivered']=release['image_id']==rebuild['image_id']==subprocess.check_output(['docker','image','inspect','local/fa4-sm120:1.0.0','--format','{{.Id}}'],text=True).strip()
rsi=REPO/'core/evolution/releases/operator-rsi-0.1.0';m=load(rsi/'manifest.json')
checks['three_RSI_versions_and_regressions']=m['status']=='validated' and all(h(REPO/p)==s for p,s in m['source_files'].items()) and h(rsi/'source.tar.gz')==m['archive_sha256'] and load(R/'reports/operator-rsi-shadow-v1.json')['pass_']
checks['task_selects_released_RSI']=load(R/'configs/rsi-versions.json')['manifest_sha256']==h(rsi/'manifest.json')
p=load(R/'paper/final-v2-manifest.json')
checks['PDF_and_LaTeX_delivered']=h(R/'paper/FA4-SM120-Final-v2.pdf')==p['pdf_sha256'] and h(R/'paper/FA4-SM120-Final-v2-LaTeX.zip')==p['latex_zip_sha256']
checks['archive_E1_integrity']='e1_checked=53, e1_unverifiable=0' in (R/'paper/final-archive-audit.log').read_text()
checks['paper_citations_and_numbers']='[OK]' in (R/'paper/final-paper-audit.log').read_text()
checks['paper_internal_and_layout']=all('FAIL 0 / WARN 0' in (R/'paper'/n).read_text() for n in ['final-internal-audit.log','final-layout.log'])
checks['no_missing_glyph_or_overflow']=not any(s in (R/'research/fa4-pro6000-final/paper/latex/main.log').read_text() for s in ['Missing character:','Overfull \\hbox','undefined references'])
checks['task_resources_stopped']=load(R/'reports/cleanup.json')['pass_']
assert all(checks.values()),checks
evidence=['reports/final-results.json','reports/rebuild.json','reports/cleanup.json','paper/final-v2-manifest.json','releases/release-manifest.json','configs/rsi-versions.json','reports/final-survey-coverage.json']
out=dict(status='complete',pass_=True,checks=checks,evidence_sha256={p:h(R/p) for p in evidence},limitations=['single physical GPU0 and fixed software','fixed inference shapes, exact tested scope only','no general decode, full-model throughput, training speed or global optimum claim','two public Nebius targets not reproduced; historical dependency failures preserved'],scope='FA4 only; external attention libraries remain controls')
(R/'reports/completion-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(len(checks),'closure checks passed')
