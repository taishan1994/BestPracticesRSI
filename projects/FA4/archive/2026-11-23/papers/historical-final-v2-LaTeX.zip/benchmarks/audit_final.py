"""Independent re-read of raw holdout samples using versioned RSI gates."""
import hashlib,importlib.util,json,statistics
from pathlib import Path
R=Path(__file__).resolve().parents[1];repo=R.parents[1]
def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
opt=load('operator_optimization',repo/'OptimizationRSI/operator.py');rep=load('operator_evidence',repo/'ReproduceRSI/operator.py')
rawpath=R/'runs/final-confirmation-combined.json';run=json.loads(rawpath.read_text());assert run['status']=='completed'
selection=json.loads((R/'configs/release-selection.json').read_text());seeds=[1009,1013,1019,1021,1031];uuid='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
preflight=rep.audit(run,candidate='fa4-qualified',shapes=list(selection),seeds=seeds,metric='graph_ms',expected_uuid=uuid);assert preflight['pass_'],preflight
preflightwall=rep.audit(run,candidate='fa4-qualified',shapes=list(selection),seeds=seeds,metric='wall_ms',expected_uuid=uuid);assert preflightwall['pass_'],preflightwall
# Every per-process artifact binds the same code and frozen policy, not merely the same labels.
binding=None
for source in run['sources']:
 p=R/source['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==source['sha256']
 d=json.loads(p.read_text());current=d['source_binding'];binding=current if binding is None else binding;assert current==binding
 for file,digest in current.items():assert hashlib.sha256((R/file).read_bytes()).hexdigest()==digest,(file,'source changed after measurement')
assert run['selection_sha256']==hashlib.sha256((R/'configs/release-selection.json').read_bytes()).hexdigest()
rows=[]
for shape,sel in selection.items():
 record=dict(shape=shape,raw_run_ref='runs/final-confirmation/'+shape+'.json')
 for metric,competitor in [('graph_ms',sel['graph_competitor']),('wall_ms',sel['wall_competitor'])]:
  record[metric]=dict(stock=opt.compare(run,shape=shape,candidate='fa4-qualified',baseline='stock',seeds=seeds,metric=metric),competitive=opt.compare(run,shape=shape,candidate='fa4-qualified',baseline=competitor,seeds=seeds,metric=metric),host_ablation=opt.compare(run,shape=shape,candidate='fa4-qualified',baseline='fa4-json',seeds=seeds,metric=metric))
 rows.append(record)
dpath=R/'runs/fa4-direct-decode-confirm.json';d=json.loads(dpath.read_text());assert d['status']=='completed'
dpre=rep.audit(d,candidate='fa4-direct-gemv',shapes=['gqa-decode-k8k-d128'],seeds=seeds,metric='graph_ms',expected_uuid=uuid);assert dpre['pass_'],dpre
for f,h in d['source_binding'].items():assert hashlib.sha256((R/f).read_bytes()).hexdigest()==h
assert d['selection_sha256']==hashlib.sha256((R/'configs/fa4-decode-protocol.json').read_bytes()).hexdigest()
decoder=dict(raw_ref=str(dpath.relative_to(R)),profile_proven=any('FlashAttentionDecodeSm120' in k for k in d.get('kernel_names',[])),readback=d['direct_readback'])
assert decoder['profile_proven']
for metric in ['graph_ms','wall_ms']:
 decoder[metric]={name:opt.compare(d,shape='gqa-decode-k8k-d128',candidate='fa4-direct-gemv',baseline=name,seeds=seeds,metric=metric) for name in ['fa4-default','fa4-gemv']}
out=dict(schema_version=1,status='audited',candidate_family='FA4 only',prefill_preflight=preflight,wall_preflight=preflightwall,raw_sha256=hashlib.sha256(rawpath.read_bytes()).hexdigest(),cases=rows,decode=decoder,threshold_pct=3,precision_erratum='reports/reference-precision-erratum.json',scope='One physical PRO6000 SE GPU0; fixed shapes/dtypes; paired round CI conditional on this protocol; no model-throughput or global-optimum claim')
(R/'reports/final-results.json').write_text(json.dumps(out,indent=2)+'\n')
for metric in ['graph_ms','wall_ms']:
 print(metric,'stock wins',sum(x[metric]['stock']['promote'] for x in rows),'competitive wins',sum(x[metric]['competitive']['promote'] for x in rows))
print('decode',[(m,decoder[m]['fa4-default']['relative_gain_pct'],decoder[m]['fa4-default']['ci95_gain_pct']) for m in ['graph_ms','wall_ms']])
