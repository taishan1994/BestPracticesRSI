"""Actual pinned ReproduceRSI comparison, with every external-condition difference retained."""
import hashlib,importlib.util,json,statistics,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[1];repo=R.parents[1];upstream=Path('/home/gob001915/compare/github/ReproduceRSI')
revision=subprocess.check_output(['git','-C',str(upstream),'rev-parse','HEAD'],text=True).strip();assert revision==json.loads((R/'configs/upstreams.json').read_text())['ReproduceRSI']
sp=importlib.util.spec_from_file_location('upstream_reproduce',upstream/'autoreproduce/core.py');core=importlib.util.module_from_spec(sp);sp.loader.exec_module(core)
sp=importlib.util.spec_from_file_location('operator_evidence',repo/'ReproduceRSI/operator.py');adapter=importlib.util.module_from_spec(sp);sp.loader.exec_module(adapter)
path=R/'runs/nebius-paired-strict.json';run=json.loads(path.read_text());assert run['status']=='completed'
reference={ 'sdxl-q1024-k77':.01323,'sdxl-q1024-k1024':.03711,'sdxl-q1536-k77':.01636,'sdxl-q1536-k1536':.08009,'sdxl-q4096-k77':.01386,'sdxl-q4096-k4096':.26568,'sdxl-q6144-k77':.01669,'sdxl-q6144-k6144':.58305,'transformer-s1024-kv4':.04540,'transformer-s1024-kv16':.04541,'transformer-s4096-kv4':.45400,'transformer-s4096-kv16':.45715}
preflight=adapter.audit(run,candidate='nebius-optimized',shapes=list(reference),seeds=[101,202,303,404,505],metric='mean_ms',expected_uuid='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c',external_reference={'source_ref':'research/nebius-optimization.md; pinned measured helper SHA10dc701a...','metric_definition':'synchronized wall ms including Python; public table median of two container block medians; local repeated block medians; aggregation difference explicit','targets':reference},expected_versions={'torch':'2.13.0+cu130','cuda':'13.0.1','cutlass':'4.6.2'})
assert preflight['pass_'],preflight
reports=[]
for shape,target in reference.items():
 expected={'gpu_model':'NVIDIA RTX PRO 6000 Blackwell Server Edition','torch':'2.13.0+cu130','cuda':'13.0.1','driver':'580.173.02','FA4_source':'eed1971f5132630dc296fe37601e834d4b57a248','metric':'median of two fresh-container medians; 1000 warmups; 9x200 calls'}
 actual={**expected,'torch':run['environment']['torch'],'cuda':run['environment']['cuda'],'driver':'615.71.09','metric':'five seed rounds in one container; each round median of 9x200 synchronized wall blocks after 1000 warmups'}
 spec=dict(source_id='src-nebius-opt',spec_id='fa4-nebius-'+shape,policy_version='fa4-reproduction-v1',conditions={k:dict(value=v,status='explicit',evidence='research/nebius-optimization.md; runs/nebius-paired-strict.json') for k,v in expected.items()},reference_metrics={'median_wall_ms':target},repeats=5,tolerance=.10)
 rows=[r for r in run['rows'] if r['shape']==shape and r['candidate']=='nebius-optimized'];assert len(rows)==5
 runs=[dict(run_id=f"nebius-strict-{shape}-{r['seed']}",valid=r['status']=='ok' and r['correctness']['pass_'],conditions=actual,metrics={'median_wall_ms':statistics.median(r['samples_ms'])}) for r in rows]
 reports.append(dict(shape=shape,spec=spec,runs=runs,report=core.evaluate(spec,runs)))
out=R/'reports/nebius-reproduction-strict.json';out.write_text(json.dumps(dict(upstream_revision=revision,upstream_core_sha256=hashlib.sha256((upstream/'autoreproduce/core.py').read_bytes()).hexdigest(),raw_run_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),preflight=preflight,shape_reports=reports,scope='Approximate software/measurement reproduction; never strict matching. Public target is not substituted by locally generated metrics.'),indent=2)+'\n')
print([(r['shape'],r['report']['status']) for r in reports])
