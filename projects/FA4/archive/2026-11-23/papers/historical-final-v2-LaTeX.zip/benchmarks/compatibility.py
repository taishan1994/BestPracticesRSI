"""Independent small FP32 autograd oracle, bottom-right masking and varlen boundaries."""
import json
import math
from pathlib import Path
import traceback
import torch
from flash_attn.cute import flash_attn_func,flash_attn_varlen_func

torch.set_float32_matmul_precision("highest")
torch.backends.cuda.matmul.allow_tf32=False
OUT=Path('/workspace/runs/compatibility-strict.json')
assert not OUT.exists()
rows=[]
def ref(q,k,v,causal):
    hq,hk=q.shape[-2],k.shape[-2]
    q,k,v=[x.transpose(1,2).float() for x in (q,k,v)]
    k=k.repeat_interleave(hq//hk,1);v=v.repeat_interleave(hq//hk,1)
    score=q@k.transpose(-1,-2)/math.sqrt(q.shape[-1])
    if causal:
        sq,sk=score.shape[-2:]
        mask=torch.arange(sk,device='cuda')[None,:]<=torch.arange(sq,device='cuda')[:,None]+sk-sq
        score=score.masked_fill(~mask,-float('inf'))
    return torch.nan_to_num(score.softmax(-1))@v

def check(a,b,atol=.02,rtol=.02):
    a=a.float();b=b.float();d=(a-b).abs()
    return dict(pass_=bool(torch.isfinite(a).all() and torch.all(d<=atol+rtol*b.abs())),max_abs=float(d.max()),rms=float(d.square().mean().sqrt()),values=a.numel())

for dtype in (torch.bfloat16,torch.float16):
 for hq,hk in [(4,4),(4,1)]:
  for causal in [False,True]:
   for sq,sk in [(129,129),(33,97)]:
    row=dict(test='dense-backward',dtype=str(dtype),hq=hq,hk=hk,causal=causal,sq=sq,sk=sk)
    try:
     torch.manual_seed(771)
     q,k,v=[torch.randn(1,s,h,64,device='cuda',dtype=dtype,requires_grad=True) for s,h in [(sq,hq),(sk,hk),(sk,hk)]]
     qr,kr,vr=[x.detach().float().requires_grad_() for x in (q,k,v)]
     o=flash_attn_func(q,k,v,causal=causal);o=o[0] if isinstance(o,tuple) else o;r=ref(qr,kr,vr,causal).transpose(1,2)
     row['forward']=check(o,r)
     grad=torch.randn_like(o);o.backward(grad);r.backward(grad.float())
     row['gradients']={name:check(x.grad,y.grad,.05,.05) for name,x,y in zip(['q','k','v'],[q,k,v],[qr,kr,vr])}
     row['pass']=row['forward']['pass_'] and all(x['pass_'] for x in row['gradients'].values())
    except Exception: row.update({'pass':False,'error':traceback.format_exc()})
    rows.append(row);print(row,flush=True)
# Nonuniform independent sequence boundaries with GQA; no pad leakage.
for causal in [False,True]:
 row=dict(test='varlen',causal=causal)
 try:
  qs=[63,129,17];ks=[97,129,65]
  torch.manual_seed(881)
  q=torch.randn(sum(qs),4,64,device='cuda',dtype=torch.bfloat16)
  k=torch.randn(sum(ks),1,64,device='cuda',dtype=torch.bfloat16);v=torch.randn_like(k)
  cuq=torch.tensor([0,63,192,209],device='cuda',dtype=torch.int32)
  cuk=torch.tensor([0,97,226,291],device='cuda',dtype=torch.int32)
  with torch.no_grad():
   o=flash_attn_varlen_func(q,k,v,cu_seqlens_q=cuq,cu_seqlens_k=cuk,max_seqlen_q=max(qs),max_seqlen_k=max(ks),causal=causal)
   o=o[0] if isinstance(o,tuple) else o
   refs=[];qi=ki=0
   for sq,sk in zip(qs,ks):
    refs.append(ref(q[None,qi:qi+sq],k[None,ki:ki+sk],v[None,ki:ki+sk],causal).transpose(1,2).squeeze(0));qi+=sq;ki+=sk
   row['forward']=check(o,torch.cat(refs));row['pass']=row['forward']['pass_']
 except Exception: row.update({'pass':False,'error':traceback.format_exc()})
 rows.append(row);print(row,flush=True)
OUT.write_text(json.dumps(dict(rows=rows,pass_=all(r['pass'] for r in rows),reference_precision=dict(allow_tf32=torch.backends.cuda.matmul.allow_tf32,float32_matmul_precision=torch.get_float32_matmul_precision())),indent=2)+'\n')
