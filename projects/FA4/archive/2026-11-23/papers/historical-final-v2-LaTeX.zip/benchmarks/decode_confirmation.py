"""Pair public FA4 wrapper env gate off/on; same source, BF16, tensors and device."""
import argparse,hashlib,json,os,statistics,time,traceback,sys
from pathlib import Path
import torch
import flash_attn
ROOT=Path('/workspace');flash_attn.__path__.insert(0,str(ROOT/'vendor/fa4-thad0ctor/flash_attn'))
from flash_attn.cute import flash_attn_func,interface
import run as base
ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['dev','confirm'],required=True);ap.add_argument('--output',required=True);ap.add_argument('--direct',action='store_true');a=ap.parse_args()
out=ROOT/a.output;assert not out.exists()
s=dict(id='gqa-decode-k8k-d128',b=1,sq=1,sk=8192,hq=16,hk=4,d=128,dtype='bfloat16',causal=False)
seeds=[61,67,71] if a.phase=='dev' else [1009,1013,1019,1021,1031]
data=dict(status='running',phase=a.phase,protocol_id='fa4-synthesis-v1-dual-timing',environment=base.env(),rows=[],patch=json.loads((ROOT/'configs/thad-decode-patch.json').read_text()),selection_sha256=hashlib.sha256((ROOT/'configs/fa4-decode-protocol.json').read_bytes()).hexdigest(),source_binding={'benchmarks/decode_confirmation.py':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
assert data['environment']['uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
if a.direct:
 sys.path.insert(0,str(ROOT/'kernels'));from compiled_decode import make_decode
 direct=make_decode(ROOT/'vendor/fa4-thad0ctor/flash_attn/cute',ROOT/'configs/thad-decode-patch.json');data['direct_readback']=direct.readback
 data['source_binding']['kernels/compiled_decode.py']=hashlib.sha256((ROOT/'kernels/compiled_decode.py').read_bytes()).hexdigest()
base.save(out,data)
for i,seed in enumerate(seeds):
 q,k,v=base.tensors(s,seed);ref=base.reference(q,k,v,s)
 methods=[('fa4-default',0),('fa4-gemv',1)]+([('fa4-direct-gemv',1)] if a.direct else [])
 for name,flag in (methods if i%2==0 else methods[::-1]):
  os.environ['FLASH_ATTENTION_SM120_DECODE_KERNEL']=str(flag)
  def fn():
   if name=='fa4-direct-gemv':return direct(q,k,v)
   o=flash_attn_func(q,k,v,causal=False);return o[0] if isinstance(o,tuple) else o
  row=dict(shape=s['id'],candidate=name,seed=seed,decode_env=str(flag))
  try:
   start=time.monotonic();row['correctness']=base.error(fn(),ref);torch.cuda.synchronize();row['first_call_seconds']=time.monotonic()-start
   if not row['correctness']['pass_']:raise ValueError('strict FP32 gate')
   g=base.graph(fn);row['graph_samples_ms']=base.measure(g);row['graph_ms']=statistics.mean(row['graph_samples_ms']);del g
   for _ in range(50):fn()
   samples=[]
   for _ in range(5):
    torch.cuda.synchronize();start=time.perf_counter()
    for _ in range(100):fn()
    torch.cuda.synchronize();samples.append((time.perf_counter()-start)*1000/100)
   row.update(status='ok',wall_samples_ms=samples,wall_ms=statistics.mean(samples))
  except Exception:row.update(status='failed',error=traceback.format_exc())
  data['rows'].append(row);base.save(out,data);print(seed,name,row.get('graph_ms'),row.get('wall_ms'),row.get('error',''),flush=True)
data['status']='completed';data['decode_compile_key_count']=len(interface._flash_attn_fwd.decode_compile_cache)
# Untimed actual CUDA kernel evidence; no profiler overhead contaminates timings.
os.environ['FLASH_ATTENTION_SM120_DECODE_KERNEL']='1'
try:
 with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
  for _ in range(3):fn()
  torch.cuda.synchronize()
 trace=out.with_suffix('.trace.json');prof.export_chrome_trace(str(trace));events=json.loads(trace.read_text())['traceEvents'];data['kernel_names']=sorted({e['name'] for e in events if e.get('cat')=='kernel'})
except Exception:data['profile_error']=traceback.format_exc()
base.save(out,data)
