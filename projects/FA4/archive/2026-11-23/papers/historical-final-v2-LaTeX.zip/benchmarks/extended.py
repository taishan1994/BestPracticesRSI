"""Research-driven extension: matched qu0b shapes, 256 threads, additional backends."""
import argparse,dataclasses,json,statistics,time,traceback
from pathlib import Path
import torch
from torch.nn.attention import sdpa_kernel,SDPBackend
import torch.nn.functional as F
import run as base
import thread_variant as tv

ROOT=Path('/workspace')

def matrix():
    original=json.loads((ROOT/'benchmarks/matrix.json').read_text())
    extra=[dict(id=name,b=b,sq=s,sk=s,hq=h,hk=h,d=d,causal=False,dtype='bfloat16') for name,b,s,h,d in [('qu0b-b1-s8192-d128',1,8192,16,128),('qu0b-b2-s4096-d128',2,4096,16,128),('qu0b-b2-s4096-d96',2,4096,16,96),('qu0b-b4-s2048-d64',4,2048,32,64)]]
    return original+extra

def options(s):
    cfg=base.default_config(s)
    yield 'stock',128,None
    screen=json.loads((ROOT/'runs/screen.json').read_text())
    rows=[r for r in screen['rows'] if r['shape']==s['id'] and r['status']=='ok' and r['candidate'] not in ('stock','torch-flash-sdpa')]
    if rows:
        names=set(r['candidate'] for r in rows)
        best=min(names,key=lambda n:statistics.mean(r['mean_ms'] for r in rows if r['candidate']==n))
        yield best,128,dict(base.candidates(s))[best]
    else:
        yield 'tile-64x128',128,dataclasses.replace(cfg,tile_m=64,tile_n=128)
    # The published tuned recipe is 256t 128x128; smaller 128x64 is a one-factor ablation.
    for n in [64,128]:
        if 2*s['d']*(128+2*n)<=101376:
            yield f't256-128x{n}',256,dataclasses.replace(cfg,tile_m=128,tile_n=n)


def backend_fn(name,q,k,v,s,cfg,threads):
    if name in ['stock'] or name.startswith(('tile-','packing-','t256-')):
        tv.activate(threads)
        return lambda:base.call(q,k,v,s,cfg)
    if name.startswith('sdpa-'):
        backend={'sdpa-flash':SDPBackend.FLASH_ATTENTION,'sdpa-cudnn':SDPBackend.CUDNN_ATTENTION}[name]
        def fn():
            with sdpa_kernel(backend):
                return F.scaled_dot_product_attention(q.transpose(1,2),k.transpose(1,2),v.transpose(1,2),is_causal=s['causal'],enable_gqa=s['hq']!=s['hk']).transpose(1,2)
        return fn
    if name=='flashinfer-fa2':
        import flashinfer
        # b>1 is deliberately not simulated by a Python loop; ragged wrapper needed.
        if s['b']!=1: raise NotImplementedError('single-prefill API only b=1; no unfair loop comparator')
        return lambda:flashinfer.single_prefill_with_kv_cache(q[0],k[0],v[0],causal=s['causal'],backend='fa2')[None]
    if name=='flex-triton':
        from torch.nn.attention.flex_attention import flex_attention,create_block_mask
        mask=None
        if s['causal']:
            def mask_mod(b,h,qi,ki):return qi>=ki
            mask=create_block_mask(mask_mod,None,None,s['sq'],s['sk'],device='cuda')
        def flex(q,k,v):
            return flex_attention(q,k,v,block_mask=mask,enable_gqa=s['hq']!=s['hk'],kernel_options={'BACKEND':'TRITON'})
        compiled=torch.compile(flex,dynamic=False)
        return lambda:compiled(q.transpose(1,2),k.transpose(1,2),v.transpose(1,2)).transpose(1,2)
    raise KeyError(name)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['screen','confirm'],required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    out=ROOT/a.output;assert not out.exists();data=dict(phase=a.phase,status='running',environment=base.env(),started=time.time(),rows=[],constructor_readbacks=tv.constructors)
    assert data['environment']['uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
    base.save(out,data)
    selection=json.loads((ROOT/'configs/selection-extended.json').read_text()) if a.phase=='confirm' else None
    for s in matrix():
        opts=list(options(s))
        backends=[('sdpa-flash',None,None),('sdpa-cudnn',None,None),('flashinfer-fa2',None,None),('flex-triton',None,None)]
        opts+=backends
        if selection:
            names=['stock',selection[s['id']]['candidate'],selection[s['id']]['competitor']]
            opts=[x for x in opts if x[0] in names]
        for i,seed in enumerate([61,67,71] if not selection else [101,202,303,404,505]):
            q,k,v=base.tensors(s,seed);ref=base.reference(q,k,v,s)
            order=opts if i%2==0 else opts[::-1]
            for name,threads,cfg in order:
                row=dict(shape=s['id'],seed=seed,candidate=name,threads=threads,config=None if cfg is None else dataclasses.asdict(cfg))
                try:
                    t=time.monotonic();fn=backend_fn(name,q,k,v,s,cfg,threads);o=fn();torch.cuda.synchronize();row['first_call_seconds']=time.monotonic()-t
                    row['correctness']=base.error(o,ref)
                    if not row['correctness']['pass_']:raise ValueError('FP32 gate')
                    g=base.graph(fn);row['samples_ms']=base.measure(g);row['mean_ms']=statistics.mean(row['samples_ms']);del g
                    # Eager diagnostic includes Python dispatch/launch; device elapsed time.
                    aa,bb=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
                    aa.record()
                    for _ in range(30):fn()
                    bb.record();bb.synchronize();row['eager_ms']=aa.elapsed_time(bb)/30
                    row['status']='ok'
                except Exception:row['status']='failed';row['error']=traceback.format_exc()
                data['rows'].append(row);base.save(out,data)
                print(s['id'],seed,name,row['status'],row.get('mean_ms',row.get('error')),flush=True)
            del q,k,v,ref
    data.update(status='completed',finished=time.time());base.save(out,data)
if __name__=='__main__':main()
