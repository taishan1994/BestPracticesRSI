import argparse,hashlib,json,statistics,sys,time,traceback
from pathlib import Path
import torch
import run as base
from synthesis import matrix,backend
ROOT=Path('/workspace');sys.path.insert(0,str(ROOT/'kernels'))
import compiled_attention as old
import compiled_attention_v2 as new
ap=argparse.ArgumentParser();ap.add_argument('--shape',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
out=ROOT/a.output;assert not out.exists()
s=next(s for s in matrix() if s['id']==a.shape)
policy=json.loads((ROOT/'configs/release-policy.json').read_text());sel=json.loads((ROOT/'configs/release-selection.json').read_text())[a.shape]
current=new.make_attention(ROOT/'configs/release-policy.json');prior=old.make_attention(ROOT/'configs/release-policy.json')
paths=[Path(__file__),ROOT/'benchmarks/run.py',ROOT/'kernels/compiled_attention.py',ROOT/'kernels/compiled_attention_v2.py',ROOT/'configs/release-policy.json']
data=dict(status='running',phase='confirm',protocol_id='fa4-synthesis-v1-dual-timing',environment=base.env(),source_binding={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},selection_sha256=hashlib.sha256((ROOT/'configs/release-selection.json').read_bytes()).hexdigest(),rows=[])
assert data['environment']['uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
base.save(out,data)
names=list(dict.fromkeys(['stock','fa4-json','fa4-qualified',sel['graph_competitor'],sel['wall_competitor']]))
for i,seed in enumerate([1009,1013,1019,1021,1031]):
 q,k,v=base.tensors(s,seed);ref=base.reference(q,k,v,s)
 for name in (names if i%2==0 else names[::-1]):
  row=dict(shape=s['id'],candidate=name,seed=seed)
  try:
   if name=='fa4-qualified':fn=lambda:current(q,k,v,causal=s['causal'])
   elif name=='fa4-json':fn=lambda:prior(q,k,v,causal=s['causal'])
   else:fn=backend(name,q,k,v,s,policy,{})
   start=time.monotonic();row['correctness']=base.error(fn(),ref);torch.cuda.synchronize();row['first_call_seconds']=time.monotonic()-start
   if not row['correctness']['pass_']:raise ValueError('strict FP32 gate')
   g=base.graph(fn);row['graph_samples_ms']=base.measure(g);row['graph_ms']=statistics.mean(row['graph_samples_ms']);del g
   for _ in range(50):fn()
   samples=[]
   for _ in range(5):
    torch.cuda.synchronize();start=time.perf_counter()
    for _ in range(100):fn()
    torch.cuda.synchronize();samples.append((time.perf_counter()-start)*1000/100)
   row.update(status='ok',wall_samples_ms=samples,wall_ms=statistics.mean(samples))
  except Exception:row.update(status='failed',error=traceback.format_exc())
  data['rows'].append(row);data['readbacks']=current.readbacks;base.save(out,data)
  print(s['id'],seed,name,row.get('graph_ms'),row.get('wall_ms'),row.get('error',''),flush=True)
  if 'illegal memory access' in row.get('error','').lower():data['status']='aborted_cuda_error';base.save(out,data);raise RuntimeError('exit poisoned case process')
data['status']='completed';base.save(out,data)
