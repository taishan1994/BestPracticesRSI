"""Isolated-process evaluation of source-pinned SM120 forks, never mixing module paths."""
import argparse,dataclasses,hashlib,importlib.util,inspect,json,math,statistics,sys,time,traceback
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--recipe',choices=['thad0ctor','lingye','snc'],required=True);p.add_argument('--output',required=True);p.add_argument('--phase',choices=['screen','confirm'],default='screen');p.add_argument('--import-only',action='store_true');p.add_argument('--shapes');a=p.parse_args()
ROOT=Path('/workspace');out=ROOT/a.output;assert not out.exists()
# Bind the import tree before importing any cute module or shared benchmark helper.
import torch
import flash_attn
source={'thad0ctor':'fa4-thad0ctor/flash_attn/cute','lingye':'fa4-lingye/flash_attn/cute','snc':'flash-attn-4-sm120/build/torch-cuda'}[a.recipe]
folder=ROOT/'vendor'/source
if a.recipe=='snc':
 spec=importlib.util.spec_from_file_location('snc_fa4',folder/'__init__.py',submodule_search_locations=[str(folder)])
 module=importlib.util.module_from_spec(spec);sys.modules['snc_fa4']=module
else:
 # Top-level flash_attn is the installed FA2 wrapper; only cute namespace resolves to fork.
 flash_attn.__path__.insert(0,str(folder.parent))
 spec=None
try:
 if spec:spec.loader.exec_module(module)
 else:module=__import__('flash_attn.cute',fromlist=['cute'])
except Exception:
 out.write_text(json.dumps(dict(recipe=a.recipe,status='import_failed',error=traceback.format_exc()),indent=2)+'\n');print(traceback.format_exc());raise SystemExit(1)
if a.import_only:
 out.write_text(json.dumps(dict(recipe=a.recipe,status='import_ok',module=inspect.getfile(module),signature=str(inspect.signature(module.flash_attn_func))),indent=2)+'\n');raise SystemExit(0)
# Import helpers whose FA4 references now bind to the selected fork; env fingerprint uses fork tree.
# SNC is separately namespaced, so report explicit module fingerprints below.
import run as base
from extended import matrix
base.torch.set_grad_enabled(False)
e=base.env();assert e['uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
e['recipe_module']=inspect.getfile(module);e['recipe_sha256']={str(x.relative_to(folder)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(folder.rglob('*.py'))}
records=[];data=dict(recipe=a.recipe,phase=a.phase,status='running',environment=e,decode_env=__import__('os').environ.get('FLASH_ATTENTION_SM120_DECODE_KERNEL','0'),started=time.time(),rows=records)
base.save(out,data)
for s in matrix():
 if a.shapes and s['id'] not in a.shapes.split(','):continue
 for seed in ([61,67,71] if a.phase=='screen' else [101,202,303,404,505]):
  q,k,v=base.tensors(s,seed);ref=base.reference(q,k,v,s)
  row=dict(shape=s['id'],seed=seed,candidate=a.recipe)
  try:
   def fn():
    r=module.flash_attn_func(q,k,v,causal=s['causal']);return r[0] if isinstance(r,tuple) else r
   t=time.monotonic();o=fn();torch.cuda.synchronize();row['first_call_seconds']=time.monotonic()-t
   row['correctness']=base.error(o,ref)
   if not row['correctness']['pass_']:raise ValueError('FP32 numerical gate')
   g=base.graph(fn);row['samples_ms']=base.measure(g);row['mean_ms']=statistics.mean(row['samples_ms']);del g
   row['status']='ok'
  except Exception:row['status']='failed';row['error']=traceback.format_exc()
  records.append(row);base.save(out,data);print(a.recipe,s['id'],seed,row['status'],row.get('mean_ms',row.get('error')),flush=True)
  del q,k,v,ref
# Preserve kernel compilation keys to read back actual paths rather than infer from recipe names.
try:
 itf=__import__(module.__name__+'.interface',fromlist=['interface'])
 data['compile_keys']=[repr(x) for x in itf._flash_attn_fwd.compile_cache]
 data['decode_compile_keys']=[repr(x) for x in getattr(itf._flash_attn_fwd,'decode_compile_cache',{})]
except Exception:data['compile_keys_error']=traceback.format_exc()
data.update(status='completed',finished=time.time());base.save(out,data)
