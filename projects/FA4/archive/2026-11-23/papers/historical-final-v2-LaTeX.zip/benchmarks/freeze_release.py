"""Freeze only development-selected FA4 configurations before holdout access."""
import hashlib,json,statistics,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]
dev=json.loads((R/'runs/synthesis-dev-combined.json').read_text());hot=json.loads((R/'runs/hotpath-dev.json').read_text());assert dev['status']==hot['status']=='completed'
parent=json.loads((R/'configs/synthesis-policy.json').read_text());selection={};policy=json.loads(json.dumps(parent))
assert not (R/'configs/release-policy.json').exists()
for key,row in policy['shapes'].items():
 s=row['id'];results=collections.defaultdict(list)
 for r in dev['rows']:
  if r['shape']==s and r['status']=='ok':results[r['candidate']].append(r)
 methods=['direct-default','direct-tuned','direct-no-qregs']
 methods=[n for n in methods if len(results[n])==3]
 chosen=min(methods,key=lambda n:statistics.mean(r['graph_ms'] for r in results[n]))
 cfg=dict(row['default'] if chosen=='direct-default' else row['tuned'])
 if chosen=='direct-no-qregs':cfg['Q_in_regs']=False
 row['tuned']=cfg;row['selection_basis']='strict-FP32 development graph mean: '+chosen
 comparators=[n for n in ['fa2','sdpa-cudnn','flashinfer'] if len(results[n])==3]
 selection[s]=dict(fa4='fa4-qualified',development_recipe=chosen,config=cfg,graph_competitor=min(comparators,key=lambda n:statistics.mean(r['graph_ms'] for r in results[n])),wall_competitor=min(comparators,key=lambda n:statistics.mean(r['wall_ms'] for r in results[n])))
policy['selection_provenance']=dict(dev='runs/synthesis-dev-combined.json',dev_sha256=hashlib.sha256((R/'runs/synthesis-dev-combined.json').read_bytes()).hexdigest(),host_path='tuple-key launcher selected from separate same-kernel short-call ablation',hotpath_sha256=hashlib.sha256((R/'runs/hotpath-dev.json').read_bytes()).hexdigest(),holdout_seeds=[1009,1013,1019,1021,1031],candidate_family='FA4 only')
(R/'configs/release-policy.json').write_text(json.dumps(policy,indent=2)+'\n');(R/'configs/release-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
print('frozen',len(selection),'FA4 shapes; holdout not yet read')
