"""One-factor host-dispatch ablation; same FA4 configs and raw GPU/wall timings."""
import hashlib,json,statistics,sys,time,traceback
from pathlib import Path
import torch
import run as base
from synthesis import matrix
ROOT=Path('/workspace');sys.path.insert(0,str(ROOT/'kernels'))
import compiled_attention as old
import compiled_attention_v2 as new
out=ROOT/'runs/hotpath-dev.json';assert not out.exists()
functions={'json-key':old.make_attention(ROOT/'configs/synthesis-policy.json'),'tuple-key':new.make_attention(ROOT/'configs/synthesis-policy.json')}
names=['mha-s1k-d64','mha-s513-d64-fp16','sdxl-q1024-k77','sdxl-q1536-k77','sdxl-q4096-k77','sdxl-q6144-k77']
data=dict(status='running',environment=base.env(),phase='one-factor-dev',protocol_id='fa4-synthesis-v1-dual-timing',source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'kernels/compiled_attention.py',ROOT/'kernels/compiled_attention_v2.py']},rows=[])
base.save(out,data)
for s in matrix():
 if s['id'] not in names:continue
 for i,seed in enumerate([181,191,211]):
  q,k,v=base.tensors(s,seed);ref=base.reference(q,k,v,s)
  for name in (list(functions) if i%2==0 else list(functions)[::-1]):
   row=dict(shape=s['id'],seed=seed,candidate=name)
   try:
    fn=lambda:functions[name](q,k,v,causal=s['causal']);row['correctness']=base.error(fn(),ref)
    if not row['correctness']['pass_']:raise ValueError('FP32 gate')
    g=base.graph(fn);row['graph_samples_ms']=base.measure(g);row['graph_ms']=statistics.mean(row['graph_samples_ms']);del g
    for _ in range(50):fn()
    samples=[]
    for _ in range(5):
     torch.cuda.synchronize();start=time.perf_counter()
     for _ in range(100):fn()
     torch.cuda.synchronize();samples.append((time.perf_counter()-start)*1000/100)
    row.update(wall_samples_ms=samples,wall_ms=statistics.mean(samples),status='ok')
   except Exception:row.update(status='failed',error=traceback.format_exc())
   data['rows'].append(row);base.save(out,data);print(row['shape'],seed,name,row.get('wall_ms'),row.get('error',''),flush=True)
data['status']='completed';base.save(out,data)
