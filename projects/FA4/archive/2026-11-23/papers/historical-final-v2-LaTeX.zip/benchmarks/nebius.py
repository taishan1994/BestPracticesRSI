"""Pinned Nebius source/helper reproduction, container-only, physical GPU0.

Uses synchronized wall time including Python call overhead. Exact software
mismatches to the public report remain explicit. No end-to-end model claim.
"""
import argparse,hashlib,importlib.util,json,statistics,time,traceback
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.nn.attention import sdpa_kernel,SDPBackend
from flash_attn.cute import flash_attn_func
from flash_attn import flash_attn_func as fa2
import run as base
ROOT=Path('/workspace');ap=argparse.ArgumentParser();ap.add_argument('--output',default='runs/nebius-paired-strict.json');arg=ap.parse_args();OUT=ROOT/arg.output;assert not OUT.exists()
SOURCE=ROOT/'research/nebius-rtx-attention-measured.py'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='10dc701a6a303561287779ea503e5e67b88874d14aa9621f74c9be8209cd70de'
sp=importlib.util.spec_from_file_location('nebius_launcher',SOURCE);module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module)
fn_tuned=module.make_inference_attention('cuda:0')
shapes=[]
for sq,h in [(1024,20),(1536,20),(4096,10),(6144,10)]:
 for sk in [77,sq]:shapes.append(dict(id=f'sdxl-q{sq}-k{sk}',b=2,sq=sq,sk=sk,hq=h,hk=h,d=64,causal=False,dtype='float16'))
for sq in [1024,4096]:
 for hk in [4,16]:shapes.append(dict(id=f'transformer-s{sq}-kv{hk}',b=2,sq=sq,sk=sq,hq=16,hk=hk,d=128,causal=True,dtype='bfloat16'))
env=base.env();assert env['uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
data=dict(status='running',started=time.time(),environment=env,protocol=dict(wall='sync, 1000 warmups, 9 blocks x 200 calls; raw block times; mean and median per call',seeds=[101,202,303,404,505],order='forward and reverse on alternate paired rounds',external_differences=['Torch 2.11 NV build vs public 2.13','CUDA 13.2 vs public 13.0.1','driver 615.71.09 vs public 580.173.02','FA2 installed NV variant vs public 2.8.4','5 seed-paired rounds vs public two container blocks']),helper_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),rows=[])
base.save(OUT,data)
for s in shapes:
 for i,seed in enumerate([101,202,303,404,505]):
  q,k,v=base.tensors(s,seed);ref=base.reference(q,k,v,s)
  def native():
   o=flash_attn_func(q,k,v,causal=s['causal']);return o[0] if isinstance(o,tuple) else o
  def helper():return fn_tuned(q,k,v,causal=s['causal'])
  def fa2_fn():return fa2(q,k,v,causal=s['causal'])
  def cudnn():
   with sdpa_kernel(SDPBackend.CUDNN_ATTENTION):
    return F.scaled_dot_product_attention(q.transpose(1,2),k.transpose(1,2),v.transpose(1,2),is_causal=s['causal'],enable_gqa=s['hq']!=s['hk']).transpose(1,2)
  opts=[('stock-fa4',native),('nebius-optimized',helper),('fa2',fa2_fn),('sdpa-cudnn',cudnn)]
  if i%2:opts.reverse()
  for name,fn in opts:
   row=dict(shape=s['id'],seed=seed,candidate=name)
   try:
    start=time.monotonic();row['correctness']=base.error(fn(),ref);torch.cuda.synchronize();row['first_call_seconds']=time.monotonic()-start
    if not row['correctness']['pass_']:raise ValueError('FP32 numerical gate')
    for _ in range(1000):fn()
    torch.cuda.synchronize();samples=[]
    for _ in range(9):
     torch.cuda.synchronize();start=time.perf_counter()
     for _ in range(200):fn()
     torch.cuda.synchronize();samples.append((time.perf_counter()-start)*1000/200)
    row.update(samples_ms=samples,mean_ms=statistics.mean(samples),median_ms=statistics.median(samples),status='ok')
   except Exception:row.update(status='failed',error=traceback.format_exc())
   data['rows'].append(row);base.save(OUT,data);print(s['id'],seed,name,row['status'],row.get('mean_ms',row.get('error')),flush=True)
  del q,k,v,ref
 data['finished_shapes']=s['id'];base.save(OUT,data)
data.update(status='completed',finished=time.time());base.save(OUT,data)
