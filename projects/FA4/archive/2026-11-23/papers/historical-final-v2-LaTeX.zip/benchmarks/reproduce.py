"""Invoke the pinned ReproduceRSI offline evaluator on numerical reproduction evidence."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--upstream',type=Path,required=True);args=p.parse_args()
rev=subprocess.check_output(['git','-C',str(args.upstream),'rev-parse','HEAD'],text=True).strip()
assert rev==json.loads((ROOT/'configs/upstreams.json').read_text())['ReproduceRSI']
sp=importlib.util.spec_from_file_location('reproduce_core',args.upstream/'autoreproduce/core.py');module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module)
data=json.loads((ROOT/'runs/screen.json').read_text());assert data['status']=='completed'
reports=[]
for shape in json.loads((ROOT/'benchmarks/matrix.json').read_text()):
 rows=[r for r in data['rows'] if r['shape']==shape['id'] and r['candidate']=='stock']
 conditions={'gpu_uuid':data['environment']['uuid'],'fa4_version':data['environment']['fa4'],'shape':shape,'reference':'chunked FP32 attention, bottom-right causal mask','tolerances':{'atol':.02,'rtol':.02}}
 spec={'source_id':'local-fp32-oracle','spec_id':'fa4-numerical-'+shape['id'],'policy_version':'fa4-sm120-v1','conditions':{k:{'value':v,'status':'explicit','evidence':'task.json; benchmarks/run.py; runs/screen.json'} for k,v in conditions.items()},'reference_metrics':{'within_tolerance_fraction':1.0},'repeats':3,'tolerance':0}
 runs=[{'run_id':f"screen-{shape['id']}-{r['seed']}",'valid':r['status']=='ok','conditions':conditions,'metrics':{'within_tolerance_fraction':1.0 if r.get('correctness',{}).get('pass_') else 0}} for r in rows]
 report=module.evaluate(spec,runs)
 reports.append(dict(shape=shape['id'],spec=spec,runs=runs,report=report))
(ROOT/'reports/reproduction.json').write_text(json.dumps({'upstream_revision':rev,'numerical_reproduction':reports,'external_performance_reproduction':{'status':'Evidence Insufficient','reason':'No matched public PRO6000 SE/SM120 shape/dtype/timing reference found. No external speed number fabricated.'}},indent=2)+'\n')
print(json.dumps({x['shape']:x['report']['status'] for x in reports},indent=2))
