"""Resume only after verified terminal backend failure; keep completed prefix immutable."""
import hashlib,importlib.util,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];REPO=R.parents[1]
sp=importlib.util.spec_from_file_location('isolation',REPO/'ReproduceRSI/isolation.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
source=R/'runs/synthesis-dev.json';old=json.loads(source.read_text())
# The prior docker exec handle exited 1 and docker top showed no worker. Do not resume live work.
assert old['status']=='aborted_backend_error'
last='qu0b-b2-s4096-d96'
ids=list(dict.fromkeys(r['shape'] for r in old['rows']));prefix=ids[:ids.index(last)]
all_shapes=json.loads((R/'configs/synthesis-policy.json').read_text())['shapes']
remaining=[x['id'] for x in all_shapes.values() if x['id'] not in prefix]
folder=R/'runs/synthesis-dev-part2';folder.mkdir(exist_ok=False)
cases=[dict(id=s,command=['docker','exec','-e','CUTE_DSL_CACHE_DIR=/workspace/.cache/synthesis','bprsi-fa4-gpu0','python','/workspace/benchmarks/synthesis.py','--phase','dev','--shapes',s,'--output','runs/synthesis-dev-part2/'+s+'.json'],artifact=str(folder/(s+'.json'))) for s in remaining]
receipts=m.run_cases(cases,folder/'receipts')
rows=[r for r in old['rows'] if r['shape'] in prefix];sources=[dict(path=str(source.relative_to(R)),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),reused_shapes=prefix)]
for case,receipt in zip(cases,receipts):
 p=Path(case['artifact']);d=json.loads(p.read_text());assert receipt['exit_code']==0 and d['status']=='completed',(case['id'],receipt)
 assert d['environment']['reference_precision']=={'allow_tf32':False,'float32_matmul_precision':'highest'}
 rows.extend(d['rows']);sources.append(dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert len(rows)==24*3*8,len(rows)
out=R/'runs/synthesis-dev-combined.json';assert not out.exists();out.write_text(json.dumps(dict(status='completed',phase='dev',environment=old['environment'],protocol_id=old['protocol_id'],rows=rows,sources=sources,policy_sha256=old['policy_sha256'],launcher_sha256=old['launcher_sha256'],recovery='Only complete shapes preceding the first fatal comparator error were reused; all remaining shapes ran in separate processes with immutable receipts'),indent=2)+'\n')
print(out)
