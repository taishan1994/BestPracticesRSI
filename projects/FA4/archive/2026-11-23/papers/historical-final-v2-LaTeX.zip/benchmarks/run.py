"""Fixed-shape FA4 correctness + sequential graph timing; all raw samples retained."""
import argparse
import dataclasses
import hashlib
import importlib.metadata as md
import inspect
import json
import math
from pathlib import Path
import statistics
import time
import traceback
import torch
import torch.nn.functional as F
from torch.nn.attention import sdpa_kernel, SDPBackend
from flash_attn.cute import flash_attn_func
from flash_attn.cute import interface

ROOT=Path('/workspace')
torch.set_grad_enabled(False)
torch.set_float32_matmul_precision("highest")
torch.backends.cuda.matmul.allow_tf32 = False

def tensors(s,seed):
    torch.manual_seed(seed)
    dt=getattr(torch,s['dtype'])
    return [torch.randn(s['b'],length,heads,s['d'],device='cuda',dtype=dt) for length,heads in [(s['sq'],s['hq']),(s['sk'],s['hk']),(s['sk'],s['hk'])]]

def reference(q,k,v,s):
    # Chunk Q to avoid quadratic FP32 score allocation on long contexts.
    q,k,v=[x.transpose(1,2).float() for x in (q,k,v)]
    if s['hq']!=s['hk']:
        k=k.repeat_interleave(s['hq']//s['hk'],1); v=v.repeat_interleave(s['hq']//s['hk'],1)
    chunks=[]
    for start in range(0,s['sq'],128):
        scores=q[:,:,start:start+128]@k.transpose(-1,-2)/math.sqrt(s['d'])
        if s['causal']:
            qi=torch.arange(start,min(start+128,s['sq']),device='cuda')+s['sk']-s['sq']
            mask=torch.arange(s['sk'],device='cuda')[None,:]<=qi[:,None]
            scores=scores.masked_fill(~mask,-float('inf'))
        chunks.append(scores.softmax(-1)@v)
    return torch.cat(chunks,2).transpose(1,2)

def error(out,ref,atol=.02,rtol=.02):
    diff=(out.float()-ref).abs()
    return dict(pass_=bool(torch.isfinite(out).all() and torch.all(diff <= atol+rtol*ref.abs())),max_abs=float(diff.max()),rms=float(diff.square().mean().sqrt()),values=out.numel())

def default_config(s):
    from flash_attn.cute.config import FwdHeuristicInputs, select_fwd_config
    return select_fwd_config(FwdHeuristicInputs(device_arch=120,num_sms=torch.cuda.get_device_properties(0).multi_processor_count,dtype=s['dtype'],head_dim=s['d'],head_dim_v=s['d'],num_heads=s['hq'],num_heads_kv=s['hk'],batch_size=s['b'],total_q=s['b']*s['sq'],total_k=s['b']*s['sk'],max_seqlen_q=s['sq'],max_seqlen_k=s['sk'],causal=s['causal'],requested_num_splits=1))

def candidates(s):
    cfg=default_config(s)
    yield 'stock',None
    # Only tile or packing differs; exclude known over-capacity launches before JIT.
    from flash_attn.cute.flash_fwd_sm120 import FlashAttentionForwardSm120
    import cutlass
    dt=cutlass.BFloat16 if s['dtype']=='bfloat16' else cutlass.Float16
    seen={cfg}
    for m,n in [(64,64),(64,128),(128,32),(128,64),(128,128)]:
        c=dataclasses.replace(cfg,tile_m=m,tile_n=n)
        if c in seen: continue
        seen.add(c)
        if FlashAttentionForwardSm120.can_implement(dt,s['d'],s['d'],m,n,1,128,s['causal']):
            yield f'tile-{m}x{n}',c
    if s['hq']!=s['hk']:
        yield 'packing-toggle',dataclasses.replace(cfg,pack_gqa=not cfg.pack_gqa)

def call(q,k,v,s,cfg):
    result = flash_attn_func(q,k,v,causal=s['causal'],**({} if cfg is None else {'config':cfg}))
    return result[0] if isinstance(result, tuple) else result

def graph(fn):
    for _ in range(5): fn()
    torch.cuda.synchronize()
    g=torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):
        for _ in range(10): fn()
    return g

def measure(g):
    samples=[]
    for _ in range(20):
        a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        a.record();g.replay();b.record();b.synchronize()
        samples.append(a.elapsed_time(b)/10)
    return samples

def env():
    files={}
    pkg=Path(inspect.getfile(interface)).parent
    for f in sorted(pkg.glob('*.py')): files[f.name]=hashlib.sha256(f.read_bytes()).hexdigest()
    return dict(reference_precision=dict(allow_tf32=torch.backends.cuda.matmul.allow_tf32,float32_matmul_precision=torch.get_float32_matmul_precision()),torch=torch.__version__,cuda=torch.version.cuda,gpu=torch.cuda.get_device_name(0),uuid='GPU-'+str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-'),capability=torch.cuda.get_device_capability(0),fa4=(md.version('flash-attn-4') if 'flash-attn-4' in {d.metadata['Name'].lower() for d in md.distributions()} else 'source-checkout'),cutlass=md.version('nvidia-cutlass-dsl'),interface=str(inspect.signature(flash_attn_func)),source_sha256=files)

def save(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)

def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['screen','confirm'],default='screen');p.add_argument('--output',required=True);a=p.parse_args()
    output=ROOT/a.output
    assert not output.exists(), 'use a new immutable run path'
    output.parent.mkdir(parents=True,exist_ok=True)
    e=env();assert e['uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c',e
    data=dict(phase=a.phase,started=time.time(),environment=e,rows=[],status='running')
    save(output,data)
    matrix=json.loads((ROOT/'benchmarks/matrix.json').read_text())
    choices=json.loads((ROOT/'configs/selection.json').read_text()) if a.phase=='confirm' else None
    for s in matrix:
        cfgs=dict(candidates(s))
        seeds=[17,29,43] if a.phase=='screen' else [101,202,303,404,505]
        if a.phase=='confirm': cfgs={k:cfgs[k] for k in dict.fromkeys(['stock',choices[s['id']]])}
        for seed in seeds:
            q,k,v=tensors(s,seed);ref=reference(q,k,v,s)
            ordered=list(cfgs.items());ordered=ordered if seed%2 else ordered[::-1]
            for name,cfg in ordered:
                row=dict(shape=s['id'],seed=seed,candidate=name,config=None if cfg is None else dataclasses.asdict(cfg))
                try:
                    t=time.monotonic();fn=lambda:call(q,k,v,s,cfg);out=fn();torch.cuda.synchronize()
                    row['first_call_seconds']=time.monotonic()-t
                    row['correctness']=error(out,ref)
                    if not row['correctness']['pass_']: raise ValueError('FP32 numerical gate failed')
                    g=graph(fn);row['samples_ms']=measure(g);row['mean_ms']=statistics.mean(row['samples_ms']);del g
                    row['status']='ok'
                except Exception:
                    row['status']='failed';row['error']=traceback.format_exc()
                data['rows'].append(row);save(output,data)
                print(s['id'],seed,name,row['status'],row.get('mean_ms',row.get('error')),flush=True)
            # Competitive fused SDPA baseline; same resident BSHD tensors, includes transpose views.
            row=dict(shape=s['id'],seed=seed,candidate='torch-flash-sdpa')
            try:
                def sdpa():
                    with sdpa_kernel(SDPBackend.FLASH_ATTENTION):
                        return F.scaled_dot_product_attention(q.transpose(1,2),k.transpose(1,2),v.transpose(1,2),is_causal=s['causal'],enable_gqa=s['hq']!=s['hk']).transpose(1,2)
                row['correctness']=error(sdpa(),ref)
                if not row['correctness']['pass_']: raise ValueError('SDPA correctness')
                g=graph(sdpa);row['samples_ms']=measure(g);row['mean_ms']=statistics.mean(row['samples_ms']);row['status']='ok';del g
            except Exception: row['status']='failed';row['error']=traceback.format_exc()
            data['rows'].append(row);save(output,data)
            del q,k,v,ref
        print('completed shape',s['id'],flush=True)
    data.update(status='completed',finished=time.time());save(output,data)

if __name__=='__main__': main()
