"""Frozen holdout orchestration; each case has a fresh, serial GPU0 process."""
import hashlib,importlib.util,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];repo=R.parents[1]
sp=importlib.util.spec_from_file_location('isolation',repo/'ReproduceRSI/isolation.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
assert json.loads((R/'runs/release-validation.json').read_text())['pass_'] is True
assert json.loads((R/'runs/decode-validation.json').read_text())['pass_'] is True
folder=R/'runs/final-confirmation';folder.mkdir(exist_ok=False)
selection=json.loads((R/'configs/release-selection.json').read_text())
cases=[dict(id=s,command=['docker','exec','bprsi-fa4-gpu0','python','/workspace/benchmarks/final_confirmation.py','--shape',s,'--output','runs/final-confirmation/'+s+'.json'],artifact=str(folder/(s+'.json'))) for s in selection]
cases.append(dict(id='fa4-direct-decode',command=['docker','exec','bprsi-fa4-gpu0','python','/workspace/benchmarks/decode_confirmation.py','--phase','confirm','--direct','--output','runs/fa4-direct-decode-confirm.json'],artifact=str(R/'runs/fa4-direct-decode-confirm.json')))
receipts=m.run_cases(cases,folder/'receipts')
rows=[];sources=[];env=None;binding=None
for case,receipt in zip(cases[:-1],receipts[:-1]):
 p=Path(case['artifact']);data=json.loads(p.read_text());assert receipt['exit_code']==0 and data['status']=='completed',(case['id'],receipt)
 env=data['environment'] if env is None else env
 assert data['environment']==env
 binding=data['selection_sha256'] if binding is None else binding;assert data['selection_sha256']==binding
 rows+=data['rows'];sources.append(dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert receipts[-1]['exit_code']==0,receipts[-1]
out=R/'runs/final-confirmation-combined.json';assert not out.exists();out.write_text(json.dumps(dict(status='completed',phase='confirm',protocol_id='fa4-synthesis-v1-dual-timing',environment=env,selection_sha256=binding,sources=sources,rows=rows),indent=2)+'\n')
print('final holdout orchestration completed',len(rows),'rows')
