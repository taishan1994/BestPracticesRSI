"""Serial followups on GPU0, after verified completion of the resumed dev handle."""
import importlib.util,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];repo=R.parents[1]
sp=importlib.util.spec_from_file_location('isolation',repo/'ReproduceRSI/isolation.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
assert json.loads((R/'runs/synthesis-dev-combined.json').read_text())['status']=='completed'
steps=[
 ('hotpath', ['docker','exec','bprsi-fa4-gpu0','python','/workspace/benchmarks/hotpath.py'], 'runs/hotpath-dev.json'),
 ('compatibility', ['docker','exec','bprsi-fa4-gpu0','python','/workspace/benchmarks/compatibility.py'], 'runs/compatibility-strict.json'),
 ('thad-gated', ['docker','exec','-e','FLASH_ATTENTION_SM120_DECODE_KERNEL=1','bprsi-fa4-gpu0','python','/workspace/benchmarks/fork_probe.py','--recipe','thad0ctor','--output','runs/thad-gated-strict.json'], 'runs/thad-gated-strict.json'),
 ('thad-default-decode', ['docker','exec','-e','FLASH_ATTENTION_SM120_DECODE_KERNEL=0','bprsi-fa4-gpu0','python','/workspace/benchmarks/fork_probe.py','--recipe','thad0ctor','--shapes','gqa-decode-k8k-d128','--output','runs/thad-default-decode-strict.json'], 'runs/thad-default-decode-strict.json'),
 ('nebius-strict', ['docker','exec','-e','NPA_FLASH_ATTN_COMMIT=eed1971f5132630dc296fe37601e834d4b57a248','bprsi-fa4-nebius-gpu0','python','/workspace/benchmarks/nebius.py'], 'runs/nebius-paired-strict.json'),
]
result=m.run_cases([dict(id=n,command=cmd,artifact=str(R/art)) for n,cmd,art in steps],R/'runs/strict-followup-receipts')
(R/'reports/strict-followup-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('followups terminal',[(x['case_id'],x['exit_code']) for x in result])
