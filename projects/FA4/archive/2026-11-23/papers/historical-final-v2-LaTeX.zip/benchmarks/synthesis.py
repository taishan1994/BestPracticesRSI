"""Preregistered source synthesis, ablations, and fresh holdout confirmation."""
import argparse,dataclasses,hashlib,json,statistics,sys,time,traceback
from pathlib import Path
import torch
import torch.nn.functional as F
from torch.nn.attention import sdpa_kernel,SDPBackend
from flash_attn import flash_attn_func as fa2
import run as base
from extended import matrix as original_matrix
import thread_variant as tv
ROOT=Path('/workspace');sys.path.insert(0,str(ROOT/'kernels'))
from compiled_attention import make_attention,shape_key

def matrix():
    shapes=original_matrix()
    for sq,h in [(1024,20),(1536,20),(4096,10),(6144,10)]:
        for sk in [77,sq]:shapes.append(dict(id=f'sdxl-q{sq}-k{sk}',b=2,sq=sq,sk=sk,hq=h,hk=h,d=64,causal=False,dtype='float16'))
    for sq in [1024,4096]:
        for hk in [4,16]:shapes.append(dict(id=f'transformer-s{sq}-kv{hk}',b=2,sq=sq,sk=sq,hq=16,hk=hk,d=128,causal=True,dtype='bfloat16'))
    return shapes

def key(s):
    return json.dumps([[s['b'],s['sq'],s['hq'],s['d']],[s['b'],s['sk'],s['hk'],s['d']],[s['b'],s['sk'],s['hk'],s['d']],s['dtype'],s['causal']],separators=(',',':'))

def prepare_policy():
    target=ROOT/'configs/synthesis-policy.json';assert not target.exists()
    screen=json.loads((ROOT/'runs/screen-extended.json').read_text());policy=dict(schema_version=1,software=base.env(),shapes={},provenance=['c-sm120','c-qu0b','c-nebius-opt'])
    for s in matrix():
        cfg=base.default_config(s)
        default=dict(tile_m=cfg.tile_m,tile_n=cfg.tile_n,num_threads=128,pack_gqa=cfg.pack_gqa,Q_in_regs=False)
        rows=[r for r in screen['rows'] if r['shape']==s['id'] and r['status']=='ok' and r['candidate'] not in ['sdpa-flash','sdpa-cudnn','flashinfer-fa2','flex-triton']]
        if rows:
            names=set(r['candidate'] for r in rows);best=min(names,key=lambda n:statistics.mean(r['mean_ms'] for r in rows if r['candidate']==n))
            chosen=next(r for r in rows if r['candidate']==best)
            c=chosen['config'] or dataclasses.asdict(cfg)
            tuned=dict(tile_m=c['tile_m'],tile_n=c['tile_n'],num_threads=chosen['threads'],pack_gqa=c['pack_gqa'],Q_in_regs=False)
        else:
            # Precisely the qualified Nebius shape rules, ported to this newer ABI.
            best='nebius-rule'
            if s['dtype']=='float16':
                tile=(64,64) if s['sk']==77 else {1024:(128,64),1536:(128,64),4096:(64,128),6144:(128,64)}[s['sq']]
                qregs=s['sk']==s['sq'] and s['sq'] in [1024,1536,6144]
            else:tile=(64,128) if s['sq']==1024 else (64,64);qregs=False
            tuned=dict(tile_m=tile[0],tile_n=tile[1],num_threads=128,pack_gqa=False,Q_in_regs=qregs)
        policy['shapes'][key(s)]=dict(id=s['id'],default=default,tuned=tuned,selection_basis=best)
    base.save(target,policy)

def backend(name,q,k,v,s,policy,launchers):
    if name.startswith('direct-'):
        return lambda:launchers[name](q,k,v,causal=s['causal'])
    if name=='stock':
        tv.activate(128);return lambda:base.call(q,k,v,s,None)
    if name=='api-tuned':
        row=policy['shapes'][key(s)]['tuned'];cfg=dataclasses.replace(base.default_config(s),tile_m=row['tile_m'],tile_n=row['tile_n'],pack_gqa=row['pack_gqa'])
        tv.activate(row['num_threads']);return lambda:base.call(q,k,v,s,cfg)
    if name=='fa2':return lambda:fa2(q,k,v,causal=s['causal'])
    if name in ['sdpa-flash','sdpa-cudnn']:
        bd=SDPBackend.FLASH_ATTENTION if name=='sdpa-flash' else SDPBackend.CUDNN_ATTENTION
        def fn():
            with sdpa_kernel(bd):return F.scaled_dot_product_attention(q.transpose(1,2),k.transpose(1,2),v.transpose(1,2),is_causal=s['causal'],enable_gqa=s['hq']!=s['hk']).transpose(1,2)
        return fn
    if name=='flashinfer':
        if s['d']%64:
            raise NotImplementedError('FA2 comparator rejected: non-multiple-of-64 head dimension triggered illegal access in recorded prior attempt')
        import flashinfer
        if s['b']==1:
            return lambda:flashinfer.single_prefill_with_kv_cache(q[0],k[0],v[0],causal=s['causal'],backend='fa2')[None]
        workspace=torch.empty(128*1024*1024,device='cuda',dtype=torch.uint8)
        wrapper=flashinfer.BatchPrefillWithRaggedKVCacheWrapper(workspace,kv_layout='NHD',backend='fa2')
        qi=torch.arange(s['b']+1,device='cuda',dtype=torch.int32)*s['sq'];ki=torch.arange(s['b']+1,device='cuda',dtype=torch.int32)*s['sk']
        wrapper.plan(qi,ki,s['hq'],s['hk'],s['d'],causal=s['causal'],q_data_type=q.dtype,kv_data_type=k.dtype)
        return lambda:wrapper.run(q.flatten(0,1),k.flatten(0,1),v.flatten(0,1)).view_as(q)
    raise KeyError(name)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['prepare','dev','confirm'],required=True);ap.add_argument('--output');ap.add_argument('--shapes');a=ap.parse_args()
    if a.phase=='prepare':prepare_policy();return
    policy=json.loads((ROOT/'configs/synthesis-policy.json').read_text())
    launchers={name:make_attention(ROOT/'configs/synthesis-policy.json',mode=mode) for name,mode in [('direct-default','default'),('direct-tuned','tuned'),('direct-no-qregs','no_qregs')]}
    out=ROOT/a.output;assert not out.exists();data=dict(status='running',phase=a.phase,started=time.time(),source_binding={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'benchmarks/run.py',ROOT/'kernels/compiled_attention.py']},environment=base.env(),policy_sha256=hashlib.sha256((ROOT/'configs/synthesis-policy.json').read_bytes()).hexdigest(),launcher_sha256=hashlib.sha256((ROOT/'kernels/compiled_attention.py').read_bytes()).hexdigest(),rows=[],protocol_id='fa4-synthesis-v1-dual-timing')
    selection=json.loads((ROOT/'configs/synthesis-selection.json').read_text()) if a.phase=='confirm' else None
    seeds=[181,191,211] if not selection else [1009,1013,1019,1021,1031]
    assert data['environment']['uuid']=='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c'
    base.save(out,data)
    for s in matrix():
        if a.shapes and s['id'] not in a.shapes.split(','):continue
        opts=['stock','api-tuned','direct-default','direct-tuned','direct-no-qregs','fa2','sdpa-cudnn','flashinfer']
        if selection:
            opts=list(dict.fromkeys(['stock',selection[s['id']]['fa4'],selection[s['id']]['wall_competitor'],selection[s['id']]['graph_competitor']]))
        for i,seed in enumerate(seeds):
            q,k,v=base.tensors(s,seed);ref=base.reference(q,k,v,s)
            for name in (opts if i%2==0 else opts[::-1]):
                row=dict(shape=s['id'],candidate=name,seed=seed)
                try:
                    start=time.monotonic();fn=backend(name,q,k,v,s,policy,launchers);o=fn();torch.cuda.synchronize();row['first_call_seconds']=time.monotonic()-start
                    row['correctness']=base.error(o,ref)
                    if not row['correctness']['pass_']:raise ValueError('FP32 numerical gate')
                    g=base.graph(fn);row['graph_samples_ms']=base.measure(g);row['graph_ms']=statistics.mean(row['graph_samples_ms']);del g
                    for _ in range(50):fn()
                    torch.cuda.synchronize();samples=[]
                    for _ in range(5):
                        torch.cuda.synchronize();start=time.perf_counter()
                        for _ in range(100):fn()
                        torch.cuda.synchronize();samples.append((time.perf_counter()-start)*1000/100)
                    row.update(wall_samples_ms=samples,wall_ms=statistics.mean(samples),status='ok')
                except Exception:row.update(status='failed',error=traceback.format_exc())
                data['rows'].append(row);data['readbacks']={n:f.readbacks for n,f in launchers.items()};base.save(out,data)
                print(s['id'],seed,name,row['status'],row.get('graph_ms'),row.get('wall_ms'),row.get('error',''),flush=True)
                if row['status']=='failed' and ('illegal memory access' in row.get('error','').lower() or 'device-side assert' in row.get('error','').lower()):
                    data.update(status='aborted_cuda_error',finished=time.time());base.save(out,data);raise RuntimeError('case process must exit after unrecoverable CUDA context error')
            del q,k,v,ref
    data.update(status='completed',finished=time.time());base.save(out,data)
if __name__=='__main__':main()
