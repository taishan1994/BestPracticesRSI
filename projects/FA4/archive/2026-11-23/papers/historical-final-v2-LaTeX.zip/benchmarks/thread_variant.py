"""Version-local adaptation of qu0b 256-thread recipe; never edits installed FA4 files.

FA4's cache key excludes thread count (hardcoded upstream), so each thread variant
owns a disjoint compile cache. A process-local constructor replacement is scoped
only to the currently measured call; graphs remain serial. Inference forward only.
"""
from flash_attn.cute import interface
from flash_attn.cute.flash_fwd_sm120 import FlashAttentionForwardSm120

Original = FlashAttentionForwardSm120
caches = {128:interface._flash_attn_fwd.compile_cache,256:{}}
constructors=[]
class Forward256(Original):
    def __init__(self,*args,**kwargs):
        kwargs['num_threads']=256
        super().__init__(*args,**kwargs)
        assert self.num_threads==256
        constructors.append(dict(threads=self.num_threads,tile_m=self.tile_m,tile_n=self.tile_n,head_dim=self.tile_hdim,pack_gqa=self.pack_gqa))

def activate(threads):
    assert threads in caches
    interface.FlashAttentionForwardSm120=Original if threads==128 else Forward256
    interface._flash_attn_fwd.compile_cache=caches[threads]
