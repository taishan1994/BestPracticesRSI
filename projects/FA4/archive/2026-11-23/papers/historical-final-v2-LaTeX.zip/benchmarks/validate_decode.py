"""Independent FP64, stream, output ownership and changed-input graph checks for FA4 decode."""
import argparse,hashlib,json,os,sys,traceback
from pathlib import Path
import torch
import flash_attn
ROOT=Path('/workspace');flash_attn.__path__.insert(0,str(ROOT/'vendor/fa4-thad0ctor/flash_attn'));sys.path.insert(0,str(ROOT/'kernels'))
import run as base
from compiled_decode import make_decode
ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args();out=ROOT/a.output;assert not out.exists()
fn=make_decode(ROOT/'vendor/fa4-thad0ctor/flash_attn/cute',ROOT/'configs/thad-decode-patch.json')
s=dict(id='decode',b=1,sq=1,sk=8192,hq=16,hk=4,d=128,dtype='bfloat16',causal=False)
rows=[]
def oracle(q,k,v):
 q,k,v=[t.transpose(1,2).double() for t in (q,k,v)];k=k.repeat_interleave(4,1);v=v.repeat_interleave(4,1)
 return ((q@k.transpose(-1,-2)/(128**.5)).softmax(-1)@v).transpose(1,2)
for seed,scale in [(443,1.),(557,3.),(991,0.)]:
 q,k,v=base.tensors(s,seed);q*=scale;k*=scale;ref=oracle(q,k,v)
 for causal in [False,True]:
  e=base.error(fn(q,k,v,causal=causal),ref);rows.append(dict(test='fp64',seed=seed,scale=scale,causal=causal,correctness=e,pass_=e['pass_']))
q,k,v=base.tensors(s,147);q2,k2,v2=base.tensors(s,257);r1=oracle(q,k,v);r2=oracle(q2,k2,v2)
a1=fn(q,k,v);a2=fn(q2,k2,v2)
rows.append(dict(test='live-output-ownership',pass_=a1.data_ptr()!=a2.data_ptr() and base.error(a1,r1)['pass_'] and base.error(a2,r2)['pass_']))
streams=[torch.cuda.Stream(),torch.cuda.Stream()]
for st in streams:st.wait_stream(torch.cuda.current_stream())
with torch.cuda.stream(streams[0]):o1=fn(q,k,v)
with torch.cuda.stream(streams[1]):o2=fn(q2,k2,v2)
for st in streams:st.synchronize()
rows.append(dict(test='separate-stream-scratch',pass_=base.error(o1,r1)['pass_'] and base.error(o2,r2)['pass_']))
graph=torch.cuda.CUDAGraph()
with torch.cuda.graph(graph):og=fn(q,k,v)
q.copy_(q2);k.copy_(k2);v.copy_(v2);graph.replay();torch.cuda.synchronize()
rows.append(dict(test='changed-input-graph',pass_=base.error(og,r2)['pass_']))
for name,call in [('grad',lambda:fn(q.requires_grad_(),k,v)),('wrong-shape',lambda:fn(q,k[:,:4096],v[:,:4096])),('mixed-dtype',lambda:fn(q,k.float(),v)),('unsupported-scale',lambda:fn(q,k,v,softmax_scale=.5))]:
 try:call();passed=False
 except (ValueError,TypeError):passed=True
 q.requires_grad_(False)
 rows.append(dict(test='reject/'+name,pass_=passed))
data=dict(status='completed',pass_=all(r['pass_'] for r in rows),environment=base.env(),reference_dtype='float64',rows=rows,readback=fn.readback,source_binding={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'kernels/compiled_decode.py',ROOT/'configs/decode-policy.json']})
base.save(out,data);print([(r['test'],r['pass_']) for r in rows]);raise SystemExit(0 if data['pass_'] else 1)
