"""GPU holdout: strict FP32, independent FP64 controls, pointer/stream/graph contracts."""
import argparse,hashlib,json,sys,traceback
from pathlib import Path
import torch
import run as base
from synthesis import matrix
ROOT=Path('/workspace');sys.path.insert(0,str(ROOT/'kernels'))
from compiled_attention_v2 import make_attention
ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args()
out=ROOT/a.output;assert not out.exists();fn=make_attention(ROOT/'configs/release-policy.json')
rows=[]
def record(name,body):
 row=dict(test=name)
 try:row.update(body());row['pass']=row.pop('pass_',row.get('pass',True))
 except Exception:row.update({'pass':False,'error':traceback.format_exc()})
 rows.append(row);print(name,row['pass'],row.get('error',''),flush=True)

for s in matrix():
 def check(s=s):
  q,k,v=base.tensors(s,443);reference=base.reference(q,k,v,s);o=fn(q,k,v,causal=s['causal']);err=base.error(o,reference)
  # Holding outputs live must prevent accidental shared-output-buffer reuse.
  q2,k2,v2=base.tensors(s,557);o2=fn(q2,k2,v2,causal=s['causal']);e2=base.error(o2,base.reference(q2,k2,v2,s))
  distinct=o.data_ptr()!=o2.data_ptr();e1=base.error(o,reference)
  # Warmed callable must bind current stream and each invocation's pointers.
  streams=[torch.cuda.Stream(),torch.cuda.Stream()]
  for stream in streams:stream.wait_stream(torch.cuda.current_stream())
  with torch.cuda.stream(streams[0]):oa=fn(q,k,v,causal=s['causal'])
  with torch.cuda.stream(streams[1]):ob=fn(q2,k2,v2,causal=s['causal'])
  for stream in streams:stream.synchronize()
  stream_ok=base.error(oa,reference)['pass_'] and base.error(ob,base.reference(q2,k2,v2,s))['pass_']
  # Captured static pointers, changed tensor contents: output must change correctly.
  graph=torch.cuda.CUDAGraph()
  with torch.cuda.graph(graph):og=fn(q,k,v,causal=s['causal'])
  q.copy_(q2);k.copy_(k2);v.copy_(v2);graph.replay();torch.cuda.synchronize()
  eg=base.error(og,base.reference(q,k,v,s));del graph
  return dict(shape=s['id'],correctness=err,changed_input=e2,old_output_preserved=e1,distinct_outputs=distinct,multistream=bool(stream_ok),changed_graph_input=eg,pass_=bool(err['pass_'] and e1['pass_'] and e2['pass_'] and distinct and stream_ok and eg['pass_']))
 record('shape-contract/'+s['id'],check)

# Different distributions and an independent float64 oracle on short controls.
for dtype in ['float16','bfloat16']:
 for causal in [False,True]:
  for scale in [0.,3.]:
   s=dict(id='fp64-control',b=1,sq=33,sk=97,hq=4,hk=1,d=64,dtype=dtype,causal=causal)
   def control(s=s,scale=scale):
    q,k,v=base.tensors(s,991);q*=scale;k*=scale
    qd,kd,vd=[x.transpose(1,2).double() for x in (q,k,v)];kd=kd.repeat_interleave(4,1);vd=vd.repeat_interleave(4,1)
    score=qd@kd.transpose(-1,-2)/(64**.5)
    if s['causal']:
     mask=torch.arange(97,device='cuda')[None,:]<=torch.arange(33,device='cuda')[:,None]+64
     score=score.masked_fill(~mask,-float('inf'))
    ref64=(score.softmax(-1)@vd).transpose(1,2)
    r32=base.reference(q,k,v,s);oracle_error=float((r32.double()-ref64).abs().max())
    result=base.error(fn(q,k,v,causal=s['causal']),ref64)
    return dict(dtype=s['dtype'],causal=s['causal'],logit_scale=scale,oracle32_vs64_max_abs=oracle_error,correctness=result,pass_=result['pass_'] and oracle_error<1e-4)
   record(f'fp64/{dtype}/{causal}/{scale}',control)

# A listed shape with padded outer strides must take native FA4, not unsafe direct ABI.
s=matrix()[0]
def strided():
 q,k,v=base.tensors(s,733);pad=torch.empty(*q.shape[:-1],q.shape[-1]+8,device='cuda',dtype=q.dtype);qq=pad[...,:q.shape[-1]];qq.copy_(q)
 e=base.error(fn(qq,k,v,causal=s['causal']),base.reference(qq,k,v,s));return dict(correctness=e,pass_=e['pass_'])
record('native-fallback/padded-stride',strided)

def rejection(name,change):
 def body():
  q,k,v=base.tensors(s,919)
  try:change(q,k,v)
  except (ValueError,TypeError,AssertionError,RuntimeError):return {'pass':True}
  return {'pass':False}
 record(name,body)
rejection('reject/grad-input',lambda q,k,v:fn(q.requires_grad_(),k,v))
def grad_mode(q,k,v):
 with torch.enable_grad():fn(q,k,v)
rejection('reject/grad-mode',grad_mode)
rejection('reject/unsupported-option',lambda q,k,v:fn(q,k,v,softmax_scale=.5))
rejection('reject/mixed-dtype',lambda q,k,v:fn(q,k.float(),v))
rejection('reject/wrong-device',lambda q,k,v:fn(q.cpu(),k,v))
# Actual CUDA kernel names, untimed after all validity tests.
q,k,v=base.tensors(matrix()[0],821);fn(q,k,v);torch.cuda.synchronize();names=[]
try:
 with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
  fn(q,k,v);torch.cuda.synchronize()
 trace=out.with_suffix('.trace.json');prof.export_chrome_trace(str(trace));names=sorted({e['name'] for e in json.loads(trace.read_text())['traceEvents'] if e.get('cat')=='kernel'})
except Exception:rows.append(dict(test='profile',pass_=False,error=traceback.format_exc()))
for row in rows:
 if 'pass_' in row:row['pass']=row.pop('pass_')
data=dict(status='completed',pass_=all(r['pass'] for r in rows),environment=base.env(),source_binding={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'kernels/compiled_attention_v2.py',ROOT/'configs/release-policy.json']},rows=rows,readbacks=fn.readbacks,kernel_names=names)
base.save(out,data)
raise SystemExit(0 if data['pass_'] else 1)
