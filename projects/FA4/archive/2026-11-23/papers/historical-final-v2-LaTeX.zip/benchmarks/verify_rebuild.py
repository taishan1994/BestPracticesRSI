"""Fresh GPU0 container verification; Docker-only host orchestration."""
import hashlib,json,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];D=R/'runs/clean-rebuild';D.mkdir(exist_ok=False)
name='bprsi-fa4-clean-rebuild-gpu0'
def command(args,log):
    p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (D/log).write_text(p.stdout)
    if p.returncode: raise RuntimeError(f'{args}: exit {p.returncode}; see {D/log}')
    return p.stdout
image=json.loads(command(['docker','image','inspect','local/fa4-sm120:1.0.0'],'image-inspect.json'))[0]
command(['docker','run','-d','--name',name,'--network','none','--gpus','device=0','--tmpfs','/cache:exec','--tmpfs','/tmp:exec','-v',f'{D}:/workspace/runs',image['Id'],'sleep','infinity'],'container-id.txt')
command(['docker','inspect',name],'container-inspect.json')
empty=command(['docker','exec',name,'python','-c',"import os,json; x=list(os.scandir('/cache')); print(json.dumps({'cache_initial_entries':len(x)})); assert not x"],'cache-initial.json')
command(['docker','exec',name,'nvidia-smi','--query-gpu=index,uuid,name,driver_version','--format=csv,noheader'],'gpu.txt')
assert 'GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c' in (D/'gpu.txt').read_text()
command(['docker','exec',name,'python','-m','pip','freeze'],'pip-freeze.txt')
for script,out in [('validate_release.py','rebuild-prefill.json'),('validate_decode.py','rebuild-decode.json')]:
    command(['docker','exec',name,'python','benchmarks/'+script,'--output','runs/'+out],out+'.log')
    assert json.loads((D/out).read_text())['pass_']
for script in ['prefill.py','decode.py']:command(['docker','exec',name,'python','examples/'+script],script+'.log')
sources=json.loads((R/'releases/fa4-sm120-1.0.0/SOURCE-MANIFEST.json').read_text())
check="import hashlib,json,pathlib; r=pathlib.Path('/workspace'); m=json.loads((r/'SOURCE-MANIFEST.json').read_text()); bad=[p for p,h in m['files'].items() if hashlib.sha256((r/p).read_bytes()).hexdigest()!=h]; print(json.dumps({'files':len(m['files']),'mismatches':bad})); assert not bad"
command(['docker','exec',name,'python','-c',check],'source-integrity.json')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(status='completed',pass_=True,image_id=image['Id'],base_image='nvcr.io/nvidia/pytorch@sha256:3c90e38f5ec51e51d1c73bd7eb3d83674a254f451147c5cadc4344314258a112',physical_gpu_uuid='GPU-a1f23cd9-9604-f48a-76dd-a6721a7d568c',container=name,cache_initial=json.loads(empty),tests={'prefill':38,'decode':13,'examples':2},source_manifest_sha256=h(R/'releases/fa4-sm120-1.0.0/SOURCE-MANIFEST.json'),evidence={str(p.relative_to(R)):h(p) for p in sorted(D.rglob('*')) if p.is_file()},scope='Fresh offline-dependency image, empty task cache, fixed GPU0; correctness and execution contracts, not an additional performance confirmation.')
(R/'reports/rebuild.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(pass_=True,image_id=image['Id'],tests=report['tests'])),flush=True)
