"""Final evidence-bound FA4 paper; preserves the separately delivered research v1."""
import csv, hashlib, importlib.util, json, re, shutil, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1]; U=R/'vendor/DeepResearchRSI'
B=R/'research/fa4-pro6000-final'; P=B/'paper'; L=P/'latex'
P.mkdir(parents=True,exist_ok=True); L.mkdir(exist_ok=True)
for name in ['documents','sources.csv','documents.csv','evidence.csv','claims.csv']:
    src=R/'research/fa4-pro6000'/name; dst=B/name
    if src.is_dir(): shutil.copytree(src,dst,dirs_exist_ok=True)
    else: shutil.copyfile(src,dst)
for name in ['tables','data','figures']: (P/name).mkdir(exist_ok=True)
load=lambda p:json.loads((R/p).read_text())
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=load('reports/final-results.json'); catalog=load('research/projects.json')
rebuild=load('reports/rebuild.json')
assert rebuild['pass_']
records=[]; numeric=[]
def claim(cid,statement,payload):
    records.append((cid,statement,json.dumps(payload,ensure_ascii=False,sort_keys=True)))
for i,c in enumerate(result['cases'],1):
    d={'case':i,'shape':c['shape']}
    for metric in ['graph_ms','wall_ms']:
        x=c[metric]['stock']; d[metric]=x
        if 'candidate_ms' not in x:
            # A failed baseline cannot supply a relative gain; the valid comparison
            # against the development-selected control still contains absolute time.
            d[metric]['absolute_candidate_us']=round(c[metric]['competitive']['candidate_ms']*1000,3)
        else:d[metric]['absolute_candidate_us']=round(x['candidate_ms']*1000,3)
    claim(f'c-local-case{i}',f"固定场景{i} {c['shape']}的五轮FA4确认；相对增益只对合格基线计算。",d)
    for m in ['graph_ms','wall_ms']:
        numeric.append(dict(case=i,metric=m,value=d[m]['absolute_candidate_us'],cite=f'c-local-case{i}'))
claim('c-local-decode','修补返回ABI后的FA4 decode直接启动器在限定BF16场景完成独立确认。',result['decode'])
claim('c-local-protocol','严格精度、源绑定、容器重建与RSI回归限定本地结论的适用范围。',dict(
    final_sha256=h(R/'reports/final-results.json'),rebuild=rebuild,
    precision_erratum=load('reports/reference-precision-erratum.json'),
    rsi=load('configs/rsi-versions.json'),qa={'native':18,'prefill':38,'decode':13,'regression':58,'replay':6},
    raw_sha256={p:h(R/p) for p in ['runs/compatibility-strict.json','runs/release-validation.json','runs/decode-validation.json','runs/nebius-paired-strict.json']},
    nebius=load('reports/nebius-reproduction-strict.json')))
snapshot='\n'.join(q for _,_,q in records)+'\n'; snap=B/'documents/doc-local-confirmation.txt';snap.write_text(snapshot)
now=datetime.now(timezone.utc).isoformat()
def append_csv(name,rows):
    path=B/name
    with path.open(newline='') as f: fields=next(csv.reader(f))
    with path.open('a',newline='') as f: csv.DictWriter(f,fieldnames=fields).writerows(rows)
append_csv('sources.csv',[dict(source_id='src-local-confirmation',url='local://FA4/reports/final-results.json',source_type='independent',publisher='本研究：GPU0容器测量',title='FA4 fixed-holdout and rebuild evidence',published_at='',updated_at='',fetched_at=now,language='zh',trust_tier='primary',access='open',license='Project evidence',notes='Open in the delivered local evidence archive, not a public external author; hashes bind raw artifacts.')])
append_csv('documents.csv',[dict(document_id='doc-local-confirmation',source_id='src-local-confirmation',content_hash=h(snap),parser_version='evidence-summary-jsonl-v1',byte_size=snap.stat().st_size,snapshot='documents/doc-local-confirmation.txt')])
append_csv('evidence.csv',[dict(evidence_id='e-'+cid[2:],document_id='doc-local-confirmation',source_id='src-local-confirmation',quote=q,locator=f'JSONL line {i}',stance='supports',extracted_by='Deterministic report export') for i,(cid,s,q) in enumerate(records,1)])
append_csv('claims.csv',[dict(claim_id=cid,statement=s,claim_type='measurement',as_of='2026-11-07',confidence='high',evidence_ids='e-'+cid[2:],counter_evidence_ids='',derivation='',notes='Local fixed-machine evidence only; original raw samples retained.',sku='se') for cid,s,q in records])
with (P/'data/absolute-times.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['case','metric','value','cite']);w.writeheader();w.writerows(numeric)
md='''# FlashAttention-4 在 SM120 上的实现调研、复现与限定优化

## 1　摘要

本文以RTX PRO 6000 Blackwell Server Edition物理GPU0为目标，研究FlashAttention-4（FA4）的SM120实现谱系、可执行配方和算子优化。调研覆盖15个项目，其中包含直接FA4实现、集成入口以及相关对照；对照后端不作为FA4产品交付。固定源码、严格参考精度和独立确认把作者报告、近似复现与本地优化分开。最终交付两个互相隔离的FA4进程配方：官方发行版上的限定形状直接启动器，以及下游FA4 BF16 decode GEMV路径。[c-sm120] [c-pr2634] [c-local-protocol]

24个固定场景全部通过候选数值门禁。五轮独立配对确认中，18个场景的图内收益、19个场景的调用收益满足预注册的“95%区间下界超过3%”规则。固定decode相对同一FA4 fork默认路径获得约8.40倍图内和5.72倍调用加速。它们是固定单卡、形状与计时协议下的结果，不是模型吞吐或全局最优声明。[c-local-decode] [c-local-protocol]

## 2　方法、精度勘误与测量边界

### 2.1　来源和模板

研究使用用户DeepResearchRSI的Source—Document—Evidence—Claim档案、原生校验器、Markdown到LaTeX转换器，以及其既有SE双栏论文模板。仅调整标题和Linux可用字体，模板来源与修改点记录在template-provenance.json。归档包含27条外部来源记录及一个本地确认来源；本地测量不被计作独立外部证据。检索追踪替代PR和完整分支，按固定版本讨论功能，不把项目名称等同于同一算法路径。[c-pr2349] [c-pr2599]

### 2.2　早期参考精度勘误

容器默认允许TF32，早期代码的.float()不能保证严格FP32矩阵乘。研究v1及早期初筛中“FP32通过”的描述须加此限定，原始文件保留且禁止据此晋升。修正后显式设置highest及allow_tf32=False，并记录读回；重跑原生兼容性、Nebius复现、开发搜索与最终门禁。前向阈值保持0.02+0.02×参考绝对值，反向保持0.05+0.05×参考绝对值；另以独立FP64控制检查FP32参考，未放宽容限。[c-local-protocol]

### 2.3　设备、容器和计时

GPU0为CC12.0，UUID结尾568c。固定NV PyTorch镜像摘要，Torch2.11开发构建、CUDA13.2、驱动615.71.09；所有GPU试验及依赖安装在容器内。产品环境为FA4 4.0.0b38、CUTLASS DSL4.8.1、Quack0.6.5；Nebius复现另用其锁定FA4源码与DSL4.6.2。主机未安装或升级Python/CUDA包。[c-local-protocol]

图内计时采用CUDA Graph，5次预热后收集20组、每组10次调用；调用计时包含Python调用与输出分配，以50次预热、5组各100次同步批次测量。两者不含首次编译和构造器初始化。最终种子1009、1013、1019、1021、1031在开发选择前冻结，逐轮交替方法顺序；每场景新进程串行执行，原始样本、退出状态与源码哈希绑定。[c-local-protocol]

### 2.4　统计和晋升

先冻结候选配置，再在独立确认轮比较成对延迟的对数比，用Student-t给出95%区间。只有区间下界增益超过3%才称确认改进；未达门槛仍保留测量。区间反映本固定机器协议的轮间变化，不能覆盖机器总体或长期环境变化。基线失败时相对增益为空，不把失败换算为无穷加速。竞争后端的选择冻结在开发阶段，仅用于检验FA4部署价值。[c-local-protocol]

## 3　SM120架构与逐项目情况

SM120官方类继承SM80路径，与SM100的tcgen05/TMEM主路径不同。发行版的SplitKV与FP8限制不能永久外推到全部下游分支；反过来，某个fork的功能表也不能证明官方发行版支持该功能。Max-Q、5090、PRO5000、SM121a和Server Edition的性能数字须保持各自硬件范围。[c-sm120] [c-splits] [c-fp8] [c-snc-performance]

'''
for i,p in enumerate(catalog['projects'],1):
    md+=f"### 3.{i}　{p['name']}\n\n**固定版本与实现。** {p['version']}。{p['sm120_status']} "+' '.join('['+c+']' for c in p['claim_ids'])+'\n\n'+p['detail']+'\n\n**限制与处置。** '+p['limitations']+f" 本地状态：{p['local_status']}。\n\n"
md+='''## 4　复现、组合来源与新增优化

### 4.1　外部配方复现

Nebius helper按作者固定源码执行12个目标，每目标5个种子、4种方法，共240行通过严格数值门禁；10个目标在作者延迟10%容限内近似复现，sdxl-q1024-k77与sdxl-q4096-k77未复现。软件环境与作者Torch2.13/CUDA13.0.1/驱动580不同，故不宣称严格复现。实际调用用户ReproduceRSI的原生评估器，另增加精度预检；公开结果和本机结果不混合计算提升。[c-nebius-opt] [c-local-protocol]

### 4.2　FA4 prefill配方

在固定发行版上组合tile、pack-GQA和Q寄存器策略，结合qu0b线程探索与Nebius缓存编译kernel思路。开发阶段对24场景、3种子、8个方法标签完成576行测量；FA4内部不同候选与外部对照分别记录。最终选择保持上游FA4数学实现，新增的直接调用层用不可变tuple查表，避免每次JSON序列化，并绑定当次指针与CUDA流。每次分配独立输出，不共享可变输出缓冲。[c-qu0b-code] [c-nebius-opt] [c-local-protocol]

未知形状或不满足直接ABI布局条件时回落到原生FA4；训练、varlen沿用已验证的原生接口，直接启动器只交付推理范围。调用层收益与tile收益分别消融，不能把Python开销减少写成kernel数学优化。D256的默认基线因共享内存配置失败，选定64×64 tile可运行，但没有相对默认路径的合格加速比。[c-local-case7]

### 4.3　FA4 decode配方

PR2634 BF16 GEMV需显式门控，默认关闭。开启后发现内部返回两项、公共包装层期待四项；本研究仅修补返回ABI并记录before/after哈希。直接启动器缓存该FA4 GEMV及其combine编译入口，每次分配私有FP32 scratch和输出，实际读回47个split。限定B1/Q1/K8192/Hq16/Hkv4/D128 BF16；因Q=1，bottom-right causal和非因果均覆盖整个KV。它与官方prefill源码树必须分进程加载，不冒充同一通用后端。[c-thad-decode-gate] [c-local-decode]

### 4.4　失败与正确性

原生dense前向/反向、矩形因果与varlen共18项严格重验通过；prefill的38项检查覆盖24场景、独立FP64、存活输出、多流、改变输入的Graph replay和拒绝不支持输入；decode另13项通过。profiler保存实际SM120 FA4及GEMV/combine内核名。FlashInfer FA2在D96的开发试验出现illegal access，该失败保留并隔离新进程恢复，不被归类成FA4失败。SNC和LingYe依赖导入失败也保留，未虚构实测速度。[c-local-protocol] [c-local-decode]

## 5　独立确认结果

![图 1](figures/fig1.png)

*图 1　代表场景的两种计时速度比；区间来自冻结的五轮配对，虚线为1.03门槛。短调用的收益主要体现在调用边界。*

图内和调用边界分开报告，避免将调用开销收益写成同等的GPU kernel收益。[c-local-case1] [c-local-case2] [c-local-case6] [c-local-case13] [c-local-case17] [c-local-case24]

表中时间单位为微秒；G/W为图内/调用相对默认FA4的几何平均速度比。Y表示对应95%收益区间下界超过3%。无Y的正值不等于确认改进；N/A表示默认基线失败。每行完整形状、dtype、原始样本和区间在随附证据中，可由case编号追溯。

'''
tables=[]
for start,end in [(0,12),(12,24)]:
    rows=['| 编号 | 图内 us | 调用 us | G/W |','| --- | --- | --- | --- |']
    for i,c in enumerate(result['cases'][start:end],start+1):
        vals=[]; times=[]
        for metric in ['graph_ms','wall_ms']:
            x=c[metric]['stock'];times.append(x.get('candidate_ms',c[metric]['competitive'].get('candidate_ms'))*1000)
            vals.append('N/A' if x['relative_gain_pct'] is None else f"{1+x['relative_gain_pct']/100:.2f}"+('Y' if x['promote'] else ''))
        rows.append(f"| {i} | {times[0]:.3f} | {times[1]:.3f} | {' / '.join(vals)} |")
    tab='\n'.join(rows)+'\n';tid=f'tab{len(tables)+1}';(P/'tables'/f'{tid}.md').write_text(tab)
    tables.append(dict(table_id=tid,caption='FA4独立确认',cites=[f'c-local-case{i}' for i in range(start+1,end+1)]))
    md+=tab+f"\n*表 {len(tables)}　场景{start+1}至{end}的FA4确认结果*\n\n"
    for i,c in enumerate(result['cases'][start:end],start+1):md+=f"场景{i}：{c['shape']}。[c-local-case{i}]\n\n"
dg=result['decode']['graph_ms']['fa4-default'];dw=result['decode']['wall_ms']['fa4-default']
md+=f'''### 5.1　限定decode与场景选择

相对同一修补fork默认路径，decode图内时间从{dg['baseline_ms']*1000:.3f}降为{dg['candidate_ms']*1000:.3f}微秒，速度比{1+dg['relative_gain_pct']/100:.3f}；调用时间从{dw['baseline_ms']*1000:.3f}降为{dw['candidate_ms']*1000:.3f}微秒，速度比{1+dw['relative_gain_pct']/100:.3f}。这里没有跨容器、跨源码计算成对比值；门控包装层与直接入口的比较另保留，用于区分内核路径收益和Python调度收益。[c-local-decode]

prefill相对默认FA4的确认改进为图内18/24、调用19/24；相对开发时选定的竞争对照为图内15/24、调用16/24。后者不改变FA4产品身份。部署按实际Graph或调用边界选择已确认路径；未确认场景保留原生FA4，D256单列已验证tile。这里没有完整模型、paged服务或训练速度结果。[c-local-protocol]

## 6　重建、部署和回滚

发布包记录固定基础镜像摘要、9个依赖wheel及其哈希、源码清单和两个示例。网络依赖下载较慢的首次构建保留为基础设施尝试，随后使用已冻结wheel离线安装完成镜像重建。新容器仅暴露物理GPU0，起始/cache为空；重新执行38项prefill和13项decode门禁及两个示例，实际版本、设备、kernel路径和退出状态记录在rebuild.json。容器验证不复用实验缓存。[c-local-protocol]

prefill初始化一次make_attention，随后在inference_mode下调用；decode在独立进程初始化make_decode，并只接受资格范围。部署文件包含具体命令。回滚时移除自定义直接调用层，使用固定原生FA4；D256须保留已验证tile或拒绝该不合格默认配置。所有回落均为FA4，不切换到FA2、cuDNN或FlashInfer。[c-local-protocol]

## 7　三个RSI的同步进化

DeepResearchRSI新增实现覆盖审计：逐项目处置、替代关系、快照哈希、源码版本和论文覆盖，同时为Linux XeLaTeX提供可重放补丁。ReproduceRSI新增可选算子证据门禁及进程隔离模块：显式精度读回、设备UUID、数值与原始计时完整性、版本差异、终态与不可变receipt；没有外部目标时只标Local Validation Only。OptimizationRSI新增固定候选、独立配对、Student-t区间及失败基线不可比较规则。[c-local-protocol]

三者作为operator-rsi-0.1.0显式选用，源码归档和回滚清单独立于原有模型SLA政策。网络隔离Python容器中58项回归通过；6个固定真实证据回放全部符合预期，包括拒绝旧参考精度、接受限定本地数值、拒绝失败基线的相对晋升。回放只重审历史证据，不伪装重新测GPU，也不把工具改进算成FA4性能收益。[c-local-protocol]

## 8　局限与结论

本研究覆盖已发现且直接相关的项目，未声称穷尽所有仓库。历史分支依赖失败、只核查文档的路线和未运行功能都保留其边界。独立确认仅覆盖一张PRO6000 SE的固定形状、dtype和推理路径；原生训练正确性不意味着训练性能提升。固定轮间区间不能替代多机器或完整模型验证。

在这些边界内，FA4本身提供可部署的SM120路径；多来源研究帮助识别线程、tile、寄存器Q、分派与decode门控，而独立测量决定哪些组合值得使用。最终交付保留FA4实现身份、严格数值门禁、可重建容器、失败证据和可回滚的RSI版本，结论限定到实际测试范围。
'''
(P/'PAPER.md').write_text(md)
(P/'paper.json').write_text(json.dumps(dict(paper_id='fa4-sm120-final-v2',slug='fa4-pro6000-final',title='FlashAttention-4 在 SM120 上的实现调研、复现与限定优化',as_of='2026-11-07',language='zh',figures=[dict(figure_id='fig1',output='fig1.png',caption='代表场景双计时',cites=['c-local-case1','c-local-case2','c-local-case6','c-local-case13','c-local-case17','c-local-case24'])],tables=tables,sections=[dict(title='逐项目分析',cites=sorted({c for p in catalog['projects'] for c in p['claim_ids']}))]),ensure_ascii=False,indent=2)+'\n')
tex=(R/'research/fa4-pro6000/paper/latex/main.tex').read_text()
begin=tex.index('\\twocolumn[{');end=tex.index('\\input{body.tex}',begin)
tex=tex[:begin]+r'''\twocolumn[{
\begin{center}
{\LARGE\bfseries\sffamily FlashAttention-4 在 SM120 上的\\[2pt]实现调研、复现与限定优化\par}
\vspace{5pt}
{\normalsize\sffamily RTX PRO 6000 Server Edition；FA4 算子最佳实践\par}
\vspace{4pt}
{\small\sffamily 最终版 v2.0；15 个项目；独立确认、干净重建与 RSI 进化\par}
\vspace{3pt}
{\small\sffamily\itshape 2026-11-07；固定单卡与限定形状，不代表模型吞吐\par}
\end{center}\vspace{6pt}
}]

'''+tex[end:]
tex=tex.replace(r'\begin{document}',r'\makeatletter\renewenvironment{table*}{\@float{table}}{\end@float}\makeatother'+'\n'+r'\begin{document}')
tex=tex.replace(r'\begin{document}',r'\captionsetup[figure]{labelformat=empty}'+'\n'+r'\begin{document}')
(L/'main.tex').write_text(tex)
prov=json.loads((R/'research/fa4-pro6000/paper/template-provenance.json').read_text());prov['edition']='final-v2.0';prov['changes']+=['four-column result tables use single-column floats','bibliography Chinese topic annotations from archived claims','figure supplied number displayed once'];(P/'template-provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
sp=importlib.util.spec_from_file_location('mdconverter',U/'scripts/md_to_tex.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sources=list(csv.DictReader((B/'sources.csv').open()));claims=list(csv.DictReader((B/'claims.csv').open()));evidence=list(csv.DictReader((B/'evidence.csv').open()));es={e['evidence_id']:e['source_id'] for e in evidence}
refs=['\\section*{参考文献与证据索引}','\\begin{refs}\\footnotesize','\\setlength{\\parindent}{0pt}']
for i,s in enumerate(sources,1):refs.append(f"\\noindent[{i}] {m.inline(s['publisher'])}. {m.inline(s['title'])}. "+'\\url{'+s['url']+'}'+f"\\par{{\\scriptsize {m.inline(s['source_id'])}；{s['fetched_at'][:10]}。}}\\par")
refs.append('\\medskip\\noindent\\textbf{主张到来源的映射}\\par')
for c in claims:refs.append('\\noindent '+m.inline('['+c['claim_id']+']')+' '+m.inline('；'.join(sorted({es[e] for e in c['evidence_ids'].split(';') if e in es})))+'\\par')
for i,source in enumerate(sources,3):
    topic=next((c['statement'] for c in claims if any(es.get(e)==source['source_id'] for e in c['evidence_ids'].split(';'))),'')
    refs[i]=refs[i].replace(r'\par{\scriptsize',r'\par '+m.inline('文档主题：'+topic)+r'\par{\scriptsize')
refs.append('\\end{refs}');(L/'references.tex').write_text('\n'.join(refs)+'\n')
subprocess.run(['docker','exec','bprsi-fa4-gpu0','python','/workspace/paper/plot_final.py'],check=True)
subprocess.run([sys.executable,str(U/'scripts/md_to_tex.py'),str(P)],check=True)
print(P)
