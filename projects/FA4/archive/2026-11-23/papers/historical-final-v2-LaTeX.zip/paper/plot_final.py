"""Scientific figure from frozen paired-round report, run inside experiment container."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
R=Path('/workspace');d=json.loads((R/'reports/final-results.json').read_text())
ids=[1,2,6,13,17,24]; y=np.arange(len(ids));fig,ax=plt.subplots(figsize=(5.0,3.2))
for m,off,color,label in [('graph_ms',-.16,'#2274a5','CUDA graph'),('wall_ms',.16,'#e87524','Python-inclusive')]:
    rows=[d['cases'][i-1][m]['stock'] for i in ids]
    means=np.array([1+x['relative_gain_pct']/100 for x in rows]);lo=np.array([1+x['ci95_gain_pct'][0]/100 for x in rows]);hi=np.array([1+x['ci95_gain_pct'][1]/100 for x in rows])
    ax.errorbar(means,y+off,xerr=[means-lo,hi-means],fmt='o',color=color,label=label,capsize=2,markersize=4)
ax.axvline(1.03,color='gray',lw=.8,ls='--');ax.set_yticks(y,[f'Case {i}' for i in ids]);ax.invert_yaxis();ax.set_xlabel('FA4 speed ratio vs same-release default (95% CI)');ax.set_xlim(.85,7.2);ax.grid(axis='x',alpha=.2);ax.legend(fontsize=8,loc='lower right');fig.tight_layout()
out=R/'research/fa4-pro6000-final/paper/figures';out.mkdir(parents=True,exist_ok=True)
for ext in ['png','svg','pdf']:fig.savefig(out/f'fig1.{ext}',dpi=220,bbox_inches='tight')
