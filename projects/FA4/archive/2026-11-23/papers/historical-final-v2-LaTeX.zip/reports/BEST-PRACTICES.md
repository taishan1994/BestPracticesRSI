# FA4 SM120 best practices

Frozen FA4-only release; no competitor substituted. All selected candidates pass strict numerical validation.

| Scenario | Graph speed ratio [95% CI] | Call speed ratio [95% CI] |
| --- | --- | --- |
| mha-s1k-d64 | 1.038 [1.030, 1.047] unconfirmed | 4.201 [3.596, 4.908] confirmed |
| mha-s2k-d128-causal | 1.354 [1.303, 1.408] confirmed | 1.374 [1.331, 1.419] confirmed |
| gqa-s2k-d128-causal | 1.275 [1.242, 1.308] confirmed | 1.298 [1.295, 1.300] confirmed |
| gqa-b4-s1k-d64 | 1.072 [1.069, 1.076] confirmed | 1.986 [1.954, 2.019] confirmed |
| mha-s4k-d128-causal | 1.232 [1.221, 1.243] confirmed | 1.232 [1.228, 1.237] confirmed |
| mha-s513-d64-fp16 | 1.835 [1.826, 1.845] confirmed | 6.562 [6.432, 6.695] confirmed |
| mha-s512-d256 | N/A: default baseline failed | N/A: default baseline failed |
| gqa-decode-k8k-d128 | 1.942 [1.941, 1.944] confirmed | 1.950 [1.948, 1.952] confirmed |
| qu0b-b1-s8192-d128 | 1.052 [1.042, 1.063] confirmed | 1.050 [1.045, 1.056] confirmed |
| qu0b-b2-s4096-d128 | 1.051 [1.039, 1.063] confirmed | 1.051 [1.047, 1.054] confirmed |
| qu0b-b2-s4096-d96 | 1.001 [0.995, 1.006] unconfirmed | 1.001 [0.998, 1.005] unconfirmed |
| qu0b-b4-s2048-d64 | 0.995 [0.981, 1.009] unconfirmed | 1.005 [1.001, 1.009] unconfirmed |
| sdxl-q1024-k77 | 1.062 [1.051, 1.073] confirmed | 6.506 [6.350, 6.666] confirmed |
| sdxl-q1024-k1024 | 1.040 [1.036, 1.044] confirmed | 2.390 [2.112, 2.704] confirmed |
| sdxl-q1536-k77 | 1.169 [1.164, 1.174] confirmed | 6.314 [6.219, 6.410] confirmed |
| sdxl-q1536-k1536 | 1.034 [1.028, 1.039] unconfirmed | 1.037 [1.034, 1.041] confirmed |
| sdxl-q4096-k77 | 1.178 [1.159, 1.198] confirmed | 6.192 [5.592, 6.856] confirmed |
| sdxl-q4096-k4096 | 1.072 [1.034, 1.112] confirmed | 1.039 [1.026, 1.053] unconfirmed |
| sdxl-q6144-k77 | 1.141 [1.126, 1.156] confirmed | 6.427 [6.319, 6.536] confirmed |
| sdxl-q6144-k6144 | 1.002 [0.997, 1.007] unconfirmed | 1.006 [1.004, 1.008] unconfirmed |
| transformer-s1024-kv4 | 1.233 [1.227, 1.239] confirmed | 1.865 [1.636, 2.127] confirmed |
| transformer-s1024-kv16 | 1.308 [1.296, 1.320] confirmed | 2.251 [2.222, 2.281] confirmed |
| transformer-s4096-kv4 | 1.156 [1.151, 1.161] confirmed | 1.157 [1.155, 1.158] confirmed |
| transformer-s4096-kv16 | 1.199 [1.196, 1.201] confirmed | 1.199 [1.198, 1.200] confirmed |

Speed ratios are paired geometric means. Promotion requires the lower 95% gain bound >3%; intervals are conditional on fixed-machine paired rounds. Choose the graph or call boundary appropriate to the application. Use native FA4 for unconfirmed cases. D256 is a qualified safe-tile exception, with no default-relative gain.

The dedicated patched PR2634 BF16 decode profile is separate: B1/Q1/K8192/Hq16/Hkv4/D128 only, approximately 8.40x graph and 5.72x call speed relative to the same fork default. No full-model or general decode claim.

See ../DEPLOYMENT.md, final-results.json, reference-precision-erratum.json and rebuild.json. Raw data and failed trials remain under ../runs/.
