# FlashAttention-4 在 SM120 上的实现调研、复现与限定优化

## 1　摘要

本文以RTX PRO 6000 Blackwell Server Edition物理GPU0为目标，研究FlashAttention-4（FA4）的SM120实现谱系、可执行配方和算子优化。调研覆盖15个项目，其中包含直接FA4实现、集成入口以及相关对照；对照后端不作为FA4产品交付。固定源码、严格参考精度和独立确认把作者报告、近似复现与本地优化分开。最终交付两个互相隔离的FA4进程配方：官方发行版上的限定形状直接启动器，以及下游FA4 BF16 decode GEMV路径。[c-sm120] [c-pr2634] [c-local-protocol]

24个固定场景全部通过候选数值门禁。五轮独立配对确认中，18个场景的图内收益、19个场景的调用收益满足预注册的“95%区间下界超过3%”规则。固定decode相对同一FA4 fork默认路径获得约8.40倍图内和5.72倍调用加速。它们是固定单卡、形状与计时协议下的结果，不是模型吞吐或全局最优声明。[c-local-decode] [c-local-protocol]

## 2　方法、精度勘误与测量边界

### 2.1　来源和模板

研究使用用户DeepResearchRSI的Source—Document—Evidence—Claim档案、原生校验器、Markdown到LaTeX转换器，以及其既有SE双栏论文模板。仅调整标题和Linux可用字体，模板来源与修改点记录在template-provenance.json。归档包含27条外部来源记录及一个本地确认来源；本地测量不被计作独立外部证据。检索追踪替代PR和完整分支，按固定版本讨论功能，不把项目名称等同于同一算法路径。[c-pr2349] [c-pr2599]

### 2.2　早期参考精度勘误

容器默认允许TF32，早期代码的.float()不能保证严格FP32矩阵乘。研究v1及早期初筛中“FP32通过”的描述须加此限定，原始文件保留且禁止据此晋升。修正后显式设置highest及allow_tf32=False，并记录读回；重跑原生兼容性、Nebius复现、开发搜索与最终门禁。前向阈值保持0.02+0.02×参考绝对值，反向保持0.05+0.05×参考绝对值；另以独立FP64控制检查FP32参考，未放宽容限。[c-local-protocol]

### 2.3　设备、容器和计时

GPU0为CC12.0，UUID结尾568c。固定NV PyTorch镜像摘要，Torch2.11开发构建、CUDA13.2、驱动615.71.09；所有GPU试验及依赖安装在容器内。产品环境为FA4 4.0.0b38、CUTLASS DSL4.8.1、Quack0.6.5；Nebius复现另用其锁定FA4源码与DSL4.6.2。主机未安装或升级Python/CUDA包。[c-local-protocol]

图内计时采用CUDA Graph，5次预热后收集20组、每组10次调用；调用计时包含Python调用与输出分配，以50次预热、5组各100次同步批次测量。两者不含首次编译和构造器初始化。最终种子1009、1013、1019、1021、1031在开发选择前冻结，逐轮交替方法顺序；每场景新进程串行执行，原始样本、退出状态与源码哈希绑定。[c-local-protocol]

### 2.4　统计和晋升

先冻结候选配置，再在独立确认轮比较成对延迟的对数比，用Student-t给出95%区间。只有区间下界增益超过3%才称确认改进；未达门槛仍保留测量。区间反映本固定机器协议的轮间变化，不能覆盖机器总体或长期环境变化。基线失败时相对增益为空，不把失败换算为无穷加速。竞争后端的选择冻结在开发阶段，仅用于检验FA4部署价值。[c-local-protocol]

## 3　SM120架构与逐项目情况

SM120官方类继承SM80路径，与SM100的tcgen05/TMEM主路径不同。发行版的SplitKV与FP8限制不能永久外推到全部下游分支；反过来，某个fork的功能表也不能证明官方发行版支持该功能。Max-Q、5090、PRO5000、SM121a和Server Edition的性能数字须保持各自硬件范围。[c-sm120] [c-splits] [c-fp8] [c-snc-performance]

### 3.1　Dao-AILab 官方 FA4

**固定版本与实现。** 4.0.0b38；源码主分支7c53542e。SM120专用类继承SM80；前向、反向和varlen已具备基本路径。 [c-install] [c-sm120] [c-splits] [c-fp8] [c-dispatch]

正式发行版是安装和回滚基线，不把B200的主性能路径等同于SM120。实际模块、设备UUID与源码哈希必须读回。BF16与FP16、因果和非因果、MHA/GQA以及非等长输入需要分别验证。 严格参考重验的18项原生dense前向/反向与varlen通过；限定24场景直接启动器另有38项质量及调用契约验证。

**限制与处置。** 本地测试发现D256默认配置超出共享内存；官方SM120不支持SplitKV及SM100 FP8。 本地状态：partially_validated。

### 3.2　qu0b/fa4-sm120-research

**固定版本与实现。** b4133047880b2ffbb164f7deec58426bd033176d。在SM120 Max-Q工作站上探索线程、tile和流水级。 [c-qu0b] [c-qu0b-code]

其公开表格覆盖四个BF16大序列shape，作者报告256线程的收益。我们保留这些shape并采用独立构造器适配，同时隔离128/256线程编译缓存。公开数字来自Max-Q，计时也不同，不能直接用于SE性能晋升。 256线程只是开发消融，不把qu0b公开百分比当作本机复现；最终发行配置由独立确认决定。

**限制与处置。** 旧脚本向内部接口注入num_threads，最新发行版不再接受该参数；GQA曾被作者排除。 本地状态：adapted_measured。

### 3.3　blake-snc 原始 TMA PR2349

**固定版本与实现。** PR2349；2026-11-07网页快照。TMA搬运与warp专门化的早期SM120实现。 [c-pr2349] [c-bledden]

此路线说明SM120缺少的是tcgen05/TMEM而非所有TMA能力。旧提案中的DMA与MMA分工是后续实现的基础，因此研究必须继续追踪作者给出的替代PR，不能以Closed状态直接淘汰其技术。

**限制与处置。** PR已关闭并指向2599；关闭原因是整合更快方案，不是硬件不支持TMA。 本地状态：not_run_superseded。

### 3.4　SecondNatureComputing HF SM120 bundle

**固定版本与实现。** 60117041e10fcc6f19882afd274318c755a5ef6e。将多个未合并PR打包，提供TMA、paged、block-sparse和dropout等功能入口。 [c-snc] [c-snc-performance]

它是完整可下载的下游分发，不等于上游当前支持矩阵。作者在SM121a上的表格显示纯吞吐不一定优于FA2，更适合按特定功能需求选用。本文把作者功能表、代码分派和本地环境失败分别记录，避免将安装成功或包装层签名当作kernel资格。 本次已尝试当前依赖及隔离旧依赖容器，仍在CUTLASS/Quack内部API导入处失败；保存失败日志，未形成可比性能结果，不能据此判为硬件不支持。

**限制与处置。** README列出SplitKV，实际分派仍限制SM12x单split；D大于128被列为不支持；新CUTLASS接口不兼容。 本地状态：dependency_blocked。

### 3.5　LingYeAI TMA 八 MMA warp PR2599

**固定版本与实现。** 44779ed18e6c92c79d8abbb04f27c450a66bf3cf。在原始TMA方案上增加MMA warp，试图缓解寄存器压力和spill。 [c-pr2599] [c-pr2349]

八个MMA warp与额外DMA warp不能简单等同于非TMA kernel的256线程。复现需要保留真实TMA类及其同步结构，单改num_threads只是消融或独立候选。作者的非因果结果并非所有点均提升，说明更大warp数不是普遍最优。 本次已尝试当前依赖及隔离旧依赖容器，仍在CUTLASS/Quack内部API导入处失败；保存失败日志，未形成可比性能结果，不能据此判为硬件不支持。

**限制与处置。** 公开实测硬件为RTX5090和PRO5000；旧内部接口与当前CUTLASS不兼容，性能因因果模式变化。 本地状态：dependency_blocked。

### 3.6　sisgrad TMAOptimized PR2406

**固定版本与实现。** PR2406；分支dz/sm120_tma_optimized。独立TMA优化路线，覆盖SplitKV、paged、varlen、pack-GQA及更多调度策略。 [c-pr2406]

它与blake-snc和LingYeAI不是同一个实现版本，不能把三个PR的收益相加。本文将其作为结构对照：哪些数据走TMA、Q是否直读寄存器、哪些共享内存区域复用、何时切换scheduler，均应由具体配置和运行证据确定。

**限制与处置。** 作者描述多数收益较小且依batch/head数变化；功能复杂，需单独数值门禁。 本地状态：not_run_ranked。

### 3.7　thad0ctor SM120 集成 PR2634

**固定版本与实现。** baabf5a1b106c3fb95c365852e2e75c0078af837。整合TMA、分派、paged、decode和较大head维度的完整SM120路径。 [c-pr2634] [c-bledden] [c-thad-decode-gate]

初筛的FP32参考精度后来发现未锁定，初筛不作资格证明。重新检查发现BF16 decode默认门控关闭；开启后还存在内部返回2项与包装层期待4项的ABI不一致。本研究仅修补返回元组，保留明确补丁与源码哈希。独立FP64、并发流、图回放和输出所有权13项检查通过；固定B1/Q1/K8192/Hq16/Hkv4/D128 BF16上完成5轮FA4直接GEMV确认。未验证该分支其他功能或通用decode范围。

**限制与处置。** 未合并主线；支持与速度取决于shape和实际分支；FP8 KV路径改变缓存精度，须单列。 本地状态：decode_scope_validated。

### 3.8　johnnynunez SM120 下游集成

**固定版本与实现。** johnnynunez/flash-attention PR1网页快照。汇集TMA八warp、score_mod反向及CUTLASS适配修复。 [c-johnny]

本项目的价值在于兼容性和功能补全线索，而不是新增一份可直接迁移的SE吞吐结果。后续复现应锁定分支头和依赖集合，并按score_mod实际触发路径检查反向，不能以普通dense前向通过代替。

**限制与处置。** 属于下游PR，不可按官方发行支持宣传；与其他TMA路线有较大谱系重叠。 本地状态：not_run_ranked。

### 3.9　Nebius Physical AI Workbench

**固定版本与实现。** FA4 eed1971f；helper源b002a53e；当前仓库72845438。在PRO6000 Server Edition上锁定FA4/CUTLASS/Quack并发布数值、算子和SDXL记录。 [c-nebius] [c-nebius-opt] [c-nebius-training]

这是与目标SKU最贴近的公开配方。它把原生调用、显式tile和缓存编译kernel的直接launcher分开，保持输出重新分配与新指针绑定，并检验多流和图回放。其结果同时展示算子收益与很小的端到端变化，因而比单一峰值TFLOPS更适合建立部署边界。 锁定helper和FA4源码后，12个公开目标中10项在10%延迟容限内达到近似复现，2项未复现；Torch/CUDA/驱动不同，不能标为严格复现。全部240行重新通过显式严格FP32数值门禁。

**限制与处置。** 优化helper仅推理；接受精确源码版本与特定shape；公开计时包含Python开销，不与图内GPU时间混比。 本地状态：approximate_reproduced。

### 3.10　PyTorch SDPA 与 FlexAttention

**固定版本与实现。** 本机Torch2.11开发构建；文档2026-11-07快照。SDPA提供Flash/cuDNN等后端；FlexAttention可用FA4或Triton生成注意力。 [c-flex] [c-sdpa-code]

它既是FA4的集成入口，也是竞争基线。本文分别强制Flash SDPA、cuDNN SDPA和Flex Triton，而不是把同一个auto接口当成稳定算法名称。包含GQA和非方形因果时，需对齐底部右对齐掩码语义，不能只检查张量维度。

**限制与处置。** Flex的GB200图表不能外推SM120；自动分派可能变化；本地只测到的路径才可参与排名。 本地状态：partially_validated。

### 3.11　NVIDIA Transformer Engine / cuDNN

**固定版本与实现。** TE2.19文档；本地cuDNN由Torch运行时读取。将FlashAttention、cuDNN fused与原生unfused作为不同后端管理。 [c-te]

最佳方案须对比同精度、同资源与同语义的后端。TE的路由规则、安装的Flash版本和cuDNN支持shape共同决定实际执行；因此必须保留独立profiler证据。仅设置环境变量或导入DotProductAttention不能证明SM120 FA4运行。

**限制与处置。** 文档功能不自动证明当前镜像TE实际选择FA4；本地cuDNN SDPA测试只覆盖该调用路径。 本地状态：documentation_and_cudnn_measurements。

### 3.12　FlashInfer

**固定版本与实现。** 0.7.3；单请求与ragged接口分别对齐。提供MHA/GQA prefill和多种decode后端；本地可强制FA2作为竞争方案。 [c-fi-release] [c-fi-code]

该项目不是FA4名称的别称，却是判断FA4算子是否值得部署的重要基线。初筛表明长KV的单token decode需要特别比较服务内核。计划阶段的workspace和预处理应与执行计时边界分开披露，batch大于1时采用真正的批量wrapper。

**限制与处置。** SM120的MLA、GEMM发布说明不能泛化为所有dense路径；单请求接口不能用Python循环伪装批量公平对照。 本地状态：partially_validated。

### 3.13　Meta xFormers

**固定版本与实现。** 2026-11-07来源快照。提供memory-efficient attention和后端封装，作为生态覆盖与兼容性线索。 [c-xformers]

记录项目而不虚构它的独立算法或性能。选用前需查询安装包包含的实际算子、架构和dtype支持，并与已纳入的后端去重。缺少本地可调用路径时，不把框架存在本身当作更强基线，也不宣称其不支持所有SM120注意力。

**限制与处置。** 本次快照未构成独立SM120 FA4性能配方；其底层实现可能与已测Flash路径重合。 本地状态：documentation_only。

### 3.14　SageAttention

**固定版本与实现。** 2026-11-07项目快照。采用INT8/INT4或FP8/FP4等量化注意力，属于相关替代路线。 [c-sage]

本文保留其覆盖位置，但不以放宽原任务数值语义换取更大加速。若业务允许量化，应另建精度协议，同时计入量化与平滑，并在真实模型上校验质量，不能将其结果标成精确BF16 FA4优化。

**限制与处置。** 量化、平滑和转换开销及精度协议与BF16精确注意力不同；不能混排kernel-only TOPS。 本地状态：excluded_from_exact_bf16_ranking。

### 3.15　CloudRift Emmy

**固定版本与实现。** 2026-11-07README快照。提供模型编译、内核调优与部署工具，相关RTX注意力研究是优化方法线索。 [c-emmy]

将其作为自动搜索、固定测量预算和消融方法的参考，而非伪造一个FA4后端。当前任务的直接可部署比较仍以已锁定源码和真实GPU执行为准。对未取得的网页正文，失败会保留为检索记录，不回填成已验证事实。

**限制与处置。** 本次README不提供可直接复现的SM120 FA4配方；不把编译器能力等同于FA4 kernel支持。 本地状态：documentation_only。

## 4　复现、组合来源与新增优化

### 4.1　外部配方复现

Nebius helper按作者固定源码执行12个目标，每目标5个种子、4种方法，共240行通过严格数值门禁；10个目标在作者延迟10%容限内近似复现，sdxl-q1024-k77与sdxl-q4096-k77未复现。软件环境与作者Torch2.13/CUDA13.0.1/驱动580不同，故不宣称严格复现。实际调用用户ReproduceRSI的原生评估器，另增加精度预检；公开结果和本机结果不混合计算提升。[c-nebius-opt] [c-local-protocol]

### 4.2　FA4 prefill配方

在固定发行版上组合tile、pack-GQA和Q寄存器策略，结合qu0b线程探索与Nebius缓存编译kernel思路。开发阶段对24场景、3种子、8个方法标签完成576行测量；FA4内部不同候选与外部对照分别记录。最终选择保持上游FA4数学实现，新增的直接调用层用不可变tuple查表，避免每次JSON序列化，并绑定当次指针与CUDA流。每次分配独立输出，不共享可变输出缓冲。[c-qu0b-code] [c-nebius-opt] [c-local-protocol]

未知形状或不满足直接ABI布局条件时回落到原生FA4；训练、varlen沿用已验证的原生接口，直接启动器只交付推理范围。调用层收益与tile收益分别消融，不能把Python开销减少写成kernel数学优化。D256的默认基线因共享内存配置失败，选定64×64 tile可运行，但没有相对默认路径的合格加速比。[c-local-case7]

### 4.3　FA4 decode配方

PR2634 BF16 GEMV需显式门控，默认关闭。开启后发现内部返回两项、公共包装层期待四项；本研究仅修补返回ABI并记录before/after哈希。直接启动器缓存该FA4 GEMV及其combine编译入口，每次分配私有FP32 scratch和输出，实际读回47个split。限定B1/Q1/K8192/Hq16/Hkv4/D128 BF16；因Q=1，bottom-right causal和非因果均覆盖整个KV。它与官方prefill源码树必须分进程加载，不冒充同一通用后端。[c-thad-decode-gate] [c-local-decode]

### 4.4　失败与正确性

原生dense前向/反向、矩形因果与varlen共18项严格重验通过；prefill的38项检查覆盖24场景、独立FP64、存活输出、多流、改变输入的Graph replay和拒绝不支持输入；decode另13项通过。profiler保存实际SM120 FA4及GEMV/combine内核名。FlashInfer FA2在D96的开发试验出现illegal access，该失败保留并隔离新进程恢复，不被归类成FA4失败。SNC和LingYe依赖导入失败也保留，未虚构实测速度。[c-local-protocol] [c-local-decode]

## 5　独立确认结果

![图 1](figures/fig1.png)

*图 1　代表场景的两种计时速度比；区间来自冻结的五轮配对，虚线为1.03门槛。短调用的收益主要体现在调用边界。*

图内和调用边界分开报告，避免将调用开销收益写成同等的GPU kernel收益。[c-local-case1] [c-local-case2] [c-local-case6] [c-local-case13] [c-local-case17] [c-local-case24]

表中时间单位为微秒；G/W为图内/调用相对默认FA4的几何平均速度比。Y表示对应95%收益区间下界超过3%。无Y的正值不等于确认改进；N/A表示默认基线失败。每行完整形状、dtype、原始样本和区间在随附证据中，可由case编号追溯。

| 编号 | 图内 us | 调用 us | G/W |
| --- | --- | --- | --- |
| 1 | 20.640 | 20.132 | 1.04 / 4.20Y |
| 2 | 84.808 | 83.746 | 1.35Y / 1.37Y |
| 3 | 83.970 | 82.872 | 1.27Y / 1.30Y |
| 4 | 53.701 | 52.232 | 1.07Y / 1.99Y |
| 5 | 261.789 | 260.110 | 1.23Y / 1.23Y |
| 6 | 8.152 | 15.639 | 1.84Y / 6.56Y |
| 7 | 21.054 | 20.702 | N/A / N/A |
| 8 | 140.919 | 140.662 | 1.94Y / 1.95Y |
| 9 | 1557.183 | 1564.324 | 1.05Y / 1.05Y |
| 10 | 792.314 | 796.445 | 1.05Y / 1.05Y |
| 11 | 578.672 | 583.287 | 1.00 / 1.00 |
| 12 | 403.093 | 410.147 | 0.99 / 1.01 |

*表 1　场景1至12的FA4确认结果*

场景1：mha-s1k-d64。[c-local-case1]

场景2：mha-s2k-d128-causal。[c-local-case2]

场景3：gqa-s2k-d128-causal。[c-local-case3]

场景4：gqa-b4-s1k-d64。[c-local-case4]

场景5：mha-s4k-d128-causal。[c-local-case5]

场景6：mha-s513-d64-fp16。[c-local-case6]

场景7：mha-s512-d256。[c-local-case7]

场景8：gqa-decode-k8k-d128。[c-local-case8]

场景9：qu0b-b1-s8192-d128。[c-local-case9]

场景10：qu0b-b2-s4096-d128。[c-local-case10]

场景11：qu0b-b2-s4096-d96。[c-local-case11]

场景12：qu0b-b4-s2048-d64。[c-local-case12]

| 编号 | 图内 us | 调用 us | G/W |
| --- | --- | --- | --- |
| 13 | 7.614 | 15.626 | 1.06Y / 6.51Y |
| 14 | 36.537 | 35.828 | 1.04Y / 2.39Y |
| 15 | 9.862 | 16.342 | 1.17Y / 6.31Y |
| 16 | 80.100 | 79.067 | 1.03 / 1.04Y |
| 17 | 11.852 | 16.401 | 1.18Y / 6.19Y |
| 18 | 255.523 | 262.112 | 1.07Y / 1.04 |
| 19 | 16.205 | 15.697 | 1.14Y / 6.43Y |
| 20 | 596.657 | 597.006 | 1.00 / 1.01 |
| 21 | 45.351 | 44.841 | 1.23Y / 1.86Y |
| 22 | 45.872 | 45.015 | 1.31Y / 2.25Y |
| 23 | 450.527 | 449.598 | 1.16Y / 1.16Y |
| 24 | 453.931 | 454.465 | 1.20Y / 1.20Y |

*表 2　场景13至24的FA4确认结果*

场景13：sdxl-q1024-k77。[c-local-case13]

场景14：sdxl-q1024-k1024。[c-local-case14]

场景15：sdxl-q1536-k77。[c-local-case15]

场景16：sdxl-q1536-k1536。[c-local-case16]

场景17：sdxl-q4096-k77。[c-local-case17]

场景18：sdxl-q4096-k4096。[c-local-case18]

场景19：sdxl-q6144-k77。[c-local-case19]

场景20：sdxl-q6144-k6144。[c-local-case20]

场景21：transformer-s1024-kv4。[c-local-case21]

场景22：transformer-s1024-kv16。[c-local-case22]

场景23：transformer-s4096-kv4。[c-local-case23]

场景24：transformer-s4096-kv16。[c-local-case24]

### 5.1　限定decode与场景选择

相对同一修补fork默认路径，decode图内时间从157.204降为18.717微秒，速度比8.399；调用时间从158.202降为27.661微秒，速度比5.720。这里没有跨容器、跨源码计算成对比值；门控包装层与直接入口的比较另保留，用于区分内核路径收益和Python调度收益。[c-local-decode]

prefill相对默认FA4的确认改进为图内18/24、调用19/24；相对开发时选定的竞争对照为图内15/24、调用16/24。后者不改变FA4产品身份。部署按实际Graph或调用边界选择已确认路径；未确认场景保留原生FA4，D256单列已验证tile。这里没有完整模型、paged服务或训练速度结果。[c-local-protocol]

## 6　重建、部署和回滚

发布包记录固定基础镜像摘要、9个依赖wheel及其哈希、源码清单和两个示例。网络依赖下载较慢的首次构建保留为基础设施尝试，随后使用已冻结wheel离线安装完成镜像重建。新容器仅暴露物理GPU0，起始/cache为空；重新执行38项prefill和13项decode门禁及两个示例，实际版本、设备、kernel路径和退出状态记录在rebuild.json。容器验证不复用实验缓存。[c-local-protocol]

prefill初始化一次make_attention，随后在inference_mode下调用；decode在独立进程初始化make_decode，并只接受资格范围。部署文件包含具体命令。回滚时移除自定义直接调用层，使用固定原生FA4；D256须保留已验证tile或拒绝该不合格默认配置。所有回落均为FA4，不切换到FA2、cuDNN或FlashInfer。[c-local-protocol]

## 7　三个RSI的同步进化

DeepResearchRSI新增实现覆盖审计：逐项目处置、替代关系、快照哈希、源码版本和论文覆盖，同时为Linux XeLaTeX提供可重放补丁。ReproduceRSI新增可选算子证据门禁及进程隔离模块：显式精度读回、设备UUID、数值与原始计时完整性、版本差异、终态与不可变receipt；没有外部目标时只标Local Validation Only。OptimizationRSI新增固定候选、独立配对、Student-t区间及失败基线不可比较规则。[c-local-protocol]

三者作为operator-rsi-0.1.0显式选用，源码归档和回滚清单独立于原有模型SLA政策。网络隔离Python容器中58项回归通过；6个固定真实证据回放全部符合预期，包括拒绝旧参考精度、接受限定本地数值、拒绝失败基线的相对晋升。回放只重审历史证据，不伪装重新测GPU，也不把工具改进算成FA4性能收益。[c-local-protocol]

## 8　局限与结论

本研究覆盖已发现且直接相关的项目，未声称穷尽所有仓库。历史分支依赖失败、只核查文档的路线和未运行功能都保留其边界。独立确认仅覆盖一张PRO6000 SE的固定形状、dtype和推理路径；原生训练正确性不意味着训练性能提升。固定轮间区间不能替代多机器或完整模型验证。

在这些边界内，FA4本身提供可部署的SM120路径；多来源研究帮助识别线程、tile、寄存器Q、分派与decode门控，而独立测量决定哪些组合值得使用。最终交付保留FA4实现身份、严格数值门禁、可重建容器、失败证据和可回滚的RSI版本，结论限定到实际测试范围。
