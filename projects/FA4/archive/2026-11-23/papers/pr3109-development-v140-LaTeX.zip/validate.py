"""Check table numbers and scope against the rendered PDF's extracted text."""
import hashlib
import json
from pathlib import Path
import re
import sys

out = Path(sys.argv[1])
facts = json.loads((out / 'facts.json').read_text())
text = (out / 'actual-text.txt').read_text()
pattern = r'^\s*([FDA]\d{2})\s+' + r'\s+'.join([r'(\d+\.\d{3})'] * 4 + [r'(\d+\.\d{6})']) + r'\s*$'
found = re.findall(pattern, text, re.M)
assert len(found) == 30, (len(found), text[-14000:])
observed = {row[0]: row[1:] for row in found}
assert len(observed) == 30
for row in facts['rows']:
    expected = [f'{v:.3f}' for v in row['original_us'] + row['candidate_us']] + [f"{row['speedup']:.6f}"]
    assert list(observed[row['label']]) == expected, (row['label'], observed[row['label']], expected)
for token in ['1.020387', '1.062565', '1.241193', '1.223993', '1.030873', '1.499657', '0.950000', '5.765371']:
    assert token in text, token
reading = re.sub(r'\s+', '', (out / 'actual-reading-order.txt').read_text())
for scope in ['本文不是完整网格结果', '尚未发布最终优化版', '补丁尚未合入当前计时源码',
              '不是V126合并版完整网格结果', '不等同于作者全部254项', '每请求32个查询',
              '显式指定tile的收益不能称为自动默认策略收益']:
    assert scope in reading, scope
assert hashlib.sha256((out / 'template-preamble.tex').read_bytes()).hexdigest() == 'c28ea12947154998da11941023f2f06023240c03d7ebc326f8626609f7e779ea'
result = dict(status='actual-PDF-all30-variant-rows-and-scope-validated', numeric_rows=30,
              timing_and_ratio_numbers=150, scope_statements_checked=7,
              PDF_sha256=hashlib.sha256((out / 'main.pdf').read_bytes()).hexdigest())
(out / 'numeric-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(result['status'])
